import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mcpholder/models/mcp_service.dart';

/// MCP服务存储服务类
/// 负责将MCP服务保存到本地存储并从本地存储中检索
class McpStorageService {
  static const String _mcpServicesKey = 'mcp_services';
  
  /// 保存MCP服务列表到本地存储
  static Future<bool> saveMcpServices(List<McpService> services) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // 将服务列表转换为JSON字符串列表
      final List<String> servicesJsonList = services.map((service) => 
        jsonEncode(service.toJson())
      ).toList();
      
      print('保存服务列表到存储: ${servicesJsonList.length}个服务');
      
      // 保存JSON字符串列表
      await prefs.setStringList(_mcpServicesKey, servicesJsonList);
      return true;
    } catch (e) {
      print('保存MCP服务失败: $e');
      return false;
    }
  }
  
  /// 从本地存储加载MCP服务列表
  static Future<List<McpService>> loadMcpServices() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // 获取JSON字符串列表
      final List<String>? servicesJsonList = prefs.getStringList(_mcpServicesKey);
      
      print('从存储加载服务列表: ${servicesJsonList?.length ?? 0}个服务');
      
      if (servicesJsonList == null || servicesJsonList.isEmpty) {
        print('存储中没有服务数据');
        return [];
      }
      
      // 将JSON字符串列表转换为McpService对象列表
      final services = servicesJsonList.map((serviceJson) {
        try {
          final Map<String, dynamic> serviceMap = jsonDecode(serviceJson);
          return McpService.fromJson(serviceMap);
        } catch (e) {
          print('解析服务JSON失败: $e, JSON: $serviceJson');
          return null;
        }
      }).where((service) => service != null).cast<McpService>().toList();
      
      print('成功加载了${services.length}个服务');
      return services;
    } catch (e) {
      print('加载MCP服务失败: $e');
      return [];
    }
  }
  
  /// 保存单个MCP服务
  /// 如果服务已存在（根据名称判断），则更新；否则添加
  static Future<bool> saveMcpService(McpService service) async {
    try {
      print('开始保存服务: ${service.name}');
      
      // 加载现有服务
      final List<McpService> existingServices = await loadMcpServices();
      
      // 检查服务是否已存在
      final int existingIndex = existingServices.indexWhere(
        (s) => s.name == service.name
      );
      
      if (existingIndex >= 0) {
        // 更新现有服务
        print('更新现有服务: ${service.name}');
        existingServices[existingIndex] = service;
      } else {
        // 添加新服务
        print('添加新服务: ${service.name}');
        existingServices.add(service);
      }
      
      // 保存更新后的服务列表
      final result = await saveMcpServices(existingServices);
      print('保存服务${result ? '成功' : '失败'}: ${service.name}');
      return result;
    } catch (e) {
      print('保存MCP服务失败: $e');
      return false;
    }
  }
  
  /// 删除MCP服务
  static Future<bool> deleteMcpService(String serviceName) async {
    try {
      // 加载现有服务
      final List<McpService> existingServices = await loadMcpServices();
      
      // 移除指定名称的服务
      existingServices.removeWhere((s) => s.name == serviceName);
      
      // 保存更新后的服务列表
      return await saveMcpServices(existingServices);
    } catch (e) {
      print('删除MCP服务失败: $e');
      return false;
    }
  }
}
