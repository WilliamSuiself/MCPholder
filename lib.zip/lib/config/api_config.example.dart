// 示例配置文件，用于GitHub仓库
// 使用时，复制此文件为api_config.dart并填入您的API密钥

class ApiConfig {
  // OpenRouter API密钥
  static const String openRouterApiKey = 'YOUR_OPENROUTER_API_KEY';
  
  // API端点
  static const String openRouterEndpoint = 'https://openrouter.ai/api/v1/chat/completions';
  
  // 其他配置
  static const int maxTokens = 2000;
  static const double temperature = 0.7;
}
