import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../models/mcp_service.dart';
import '../services/mcp_storage_service.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  // MCP服务列表
  List<McpService> _services = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  // 从存储加载MCP服务
  Future<void> _loadServices() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
      });
    }

    try {
      // 从存储加载服务
      final storedServices = await McpStorageService.loadMcpServices();
      
      // 如果没有存储的服务，添加默认服务
      if (storedServices.isEmpty) {
        _services = _getDefaultServices();
        // 保存默认服务到存储
        await McpStorageService.saveMcpServices(_services);
      } else {
        _services = storedServices;
      }
    } catch (e) {
      print('加载MCP服务失败: $e');
      // 出错时使用默认服务
      _services = _getDefaultServices();
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // 获取默认服务列表（用于首次运行或加载失败时）
  List<McpService> _getDefaultServices() {
    return [
      McpService(
        name: 'GitHub',
        description: '访问GitHub仓库和API',
        isActive: true,
        icon: FontAwesomeIcons.github,
        tools: [
          {
            'name': 'searchRepo',
            'description': '搜索GitHub仓库',
            'parameters': {
              'type': 'object',
              'properties': {
                'query': {'type': 'string', 'description': '搜索关键词'},
                'language': {'type': 'string', 'description': '编程语言'},
              },
              'required': ['query'],
            },
          },
          {
            'name': 'createIssue',
            'description': '创建GitHub Issue',
            'parameters': {
              'type': 'object',
              'properties': {
                'repo': {'type': 'string', 'description': '仓库名称'},
                'title': {'type': 'string', 'description': 'Issue标题'},
                'body': {'type': 'string', 'description': 'Issue内容'},
              },
              'required': ['repo', 'title'],
            },
          }
        ],
      ),
      McpService(
        name: 'Gmail',
        description: '发送和管理电子邮件',
        isActive: true,
        icon: FontAwesomeIcons.envelope,
        tools: [
          {
            'name': 'sendEmail',
            'description': '发送电子邮件',
            'parameters': {
              'type': 'object',
              'properties': {
                'to': {'type': 'string', 'description': '收件人'},
                'subject': {'type': 'string', 'description': '邮件主题'},
                'body': {'type': 'string', 'description': '邮件内容'},
              },
              'required': ['to', 'subject'],
            },
          },
          {
            'name': 'readEmails',
            'description': '读取收件箱邮件',
            'parameters': {
              'type': 'object',
              'properties': {
                'count': {'type': 'integer', 'description': '邮件数量'},
                'unreadOnly': {'type': 'boolean', 'description': '只读未读邮件'},
              },
            },
          }
        ],
      ),
      McpService(
        name: 'Calendar',
        description: '日历日程管理',
        isActive: false,
        icon: FontAwesomeIcons.calendar,
        tools: [
          {
            'name': 'addEvent',
            'description': '添加日历事件',
            'parameters': {
              'type': 'object',
              'properties': {
                'title': {'type': 'string', 'description': '事件标题'},
                'start': {'type': 'string', 'description': '开始时间'},
                'end': {'type': 'string', 'description': '结束时间'},
                'description': {'type': 'string', 'description': '事件描述'},
              },
              'required': ['title', 'start'],
            },
          },
          {
            'name': 'getEvents',
            'description': '获取日历事件',
            'parameters': {
              'type': 'object',
              'properties': {
                'date': {'type': 'string', 'description': '日期'},
                'count': {'type': 'integer', 'description': '事件数量'},
              },
            },
          }
        ],
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MCP服务'),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  color: Colors.indigo.withOpacity(0.05),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'MCP服务',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.indigo,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Model Context Protocol (MCP) 允许AI模型通过外部工具和API执行操作。',
                        style: TextStyle(
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: _buildStatusCard(
                              title: '已连接',
                              value: _services.where((s) => s.isActive).length.toString(),
                              color: Colors.green,
                              icon: Icons.check_circle,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: _buildStatusCard(
                              title: '未连接',
                              value: _services.where((s) => !s.isActive).length.toString(),
                              color: Colors.orange,
                              icon: Icons.error,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: _buildStatusCard(
                              title: '可用工具',
                              value: _services.fold<int>(0, 
                                (sum, service) => sum + (service.isActive ? service.tools.length : 0)
                              ).toString(),
                              color: Colors.blue,
                              icon: Icons.build,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: _services.length,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemBuilder: (context, index) {
                      final service = _services[index];
                      return Card(
                        margin:
                            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          leading: CircleAvatar(
                            backgroundColor:
                                service.isActive ? Colors.indigo : Colors.grey[300],
                            child: FaIcon(
                              service.icon,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                          title: Row(
                            children: [
                              Text(
                                service.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (service.tools.isNotEmpty) ...[
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    '${service.tools.length}个工具',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.blue[700],
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          subtitle: Text(service.description),
                          trailing: Switch(
                            value: service.isActive,
                            activeColor: Colors.indigo,
                            onChanged: (value) {
                              setState(() {
                                service.isActive = value;
                              });
                            },
                          ),
                          onTap: () {
                            _showServiceDetails(service);
                          },
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          try {
            final result = await Navigator.pushNamed(context, '/test-service');
            if (result != null && result is McpService) {
              print('接收到新服务: ${result.name}');
              
              // 显示加载指示器
              if (mounted) {
                setState(() {
                  _isLoading = true;
                });
              }
              
              try {
                // 检查是否已存在同名服务，如果有则更新，否则添加
                final newService = result;
                final existingIndex = _services.indexWhere((s) => s.name == newService.name);
                if (existingIndex >= 0) {
                  _services[existingIndex] = newService;
                } else {
                  _services.add(newService);
                }
                
                // 保存服务列表到存储
                await McpStorageService.saveMcpServices(_services);
                
                // 重新加载服务列表，确保显示最新数据
                await _loadServices();
                
                // 显示成功消息
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('MCP服务 ${newService.name} 已添加到列表'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              } catch (e) {
                print('更新服务列表时出错: $e');
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('更新服务列表失败: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              } finally {
                // 关闭加载指示器
                if (mounted) {
                  setState(() {
                    _isLoading = false;
                  });
                }
              }
            }
          } catch (e) {
            print('导航或处理结果时出错: $e');
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('操作失败: $e'),
                  backgroundColor: Colors.red,
                ),
              );
            }
          }
        },
        backgroundColor: Colors.indigo,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildStatusCard({
    required String title,
    required String value,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 16),
              const SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  color: color,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  void _showServiceDetails(McpService service) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Container(
              padding: const EdgeInsets.all(24),
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.8,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor:
                            service.isActive ? Colors.indigo : Colors.grey[300],
                        radius: 24,
                        child: FaIcon(
                          service.icon,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            service.name,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            service.isActive ? '已连接' : '未连接',
                            style: TextStyle(
                              color:
                                  service.isActive ? Colors.green : Colors.orange,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      // 添加删除按钮
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          // 关闭详情对话框
                          Navigator.of(context).pop();
                          // 显示确认对话框
                          _showDeleteConfirmation(service);
                        },
                        tooltip: '删除服务',
                      ),
                      Switch(
                        value: service.isActive,
                        activeColor: Colors.indigo,
                        onChanged: (value) {
                          setState(() {
                            service.isActive = value;
                          });
                          // 更新父级状态
                          this.setState(() {});
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    '服务描述',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    service.description,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'MCP工具',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (service.isRemote)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.indigo.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.cloud,
                                size: 14,
                                color: Colors.indigo,
                              ),
                              const SizedBox(width: 4),
                              const Text(
                                '远程MCP服务',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.indigo,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  if (service.tools.isEmpty)
                    const Text(
                      '该服务没有提供任何工具',
                      style: TextStyle(
                        fontStyle: FontStyle.italic,
                        color: Colors.grey,
                      ),
                    )
                  else
                    Expanded(
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: service.tools.length,
                        itemBuilder: (context, index) {
                          final tool = service.tools[index];
                          // 检查工具是否启用
                          final bool isToolEnabled = tool['enabled'] ?? true;
                          
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ExpansionTile(
                              leading: Icon(
                                Icons.build,
                                color: isToolEnabled ? Colors.indigo : Colors.grey,
                              ),
                              title: Text(
                                tool['name'],
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: isToolEnabled ? Colors.black87 : Colors.grey,
                                ),
                              ),
                              subtitle: Text(
                                tool['description'] ?? '无描述',
                                style: TextStyle(
                                  color: isToolEnabled ? Colors.black54 : Colors.grey,
                                ),
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Switch(
                                    value: isToolEnabled,
                                    activeColor: Colors.indigo,
                                    onChanged: service.isActive 
                                        ? (value) {
                                            setState(() {
                                              tool['enabled'] = value;
                                            });
                                            // 更新父级状态
                                            this.setState(() {});
                                          }
                                        : null,
                                  ),
                                  service.isRemote
                                      ? const Chip(
                                          label: Text('远程'),
                                          backgroundColor: Colors.indigo,
                                          labelStyle: TextStyle(color: Colors.white, fontSize: 10),
                                          padding: EdgeInsets.zero,
                                        )
                                      : const Chip(
                                          label: Text('本地'),
                                          backgroundColor: Colors.orange,
                                          labelStyle: TextStyle(color: Colors.white, fontSize: 10),
                                          padding: EdgeInsets.zero,
                                        ),
                                ],
                              ),
                              children: [
                                if (tool['parameters'] != null) ...[
                                  Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          '参数定义',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.indigo,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        if (tool['parameters']['properties'] != null) ...[
                                          ...((tool['parameters']['properties'] as Map<String, dynamic>).entries.map((entry) {
                                            final isRequired = (tool['parameters']['required'] as List?)?.contains(entry.key) ?? false;
                                            return Padding(
                                              padding: const EdgeInsets.only(bottom: 4),
                                              child: Row(
                                                children: [
                                                  Text(
                                                    entry.key,
                                                    style: const TextStyle(
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  if (isRequired)
                                                    Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      decoration: BoxDecoration(
                                                        color: Colors.red.withOpacity(0.1),
                                                        borderRadius: BorderRadius.circular(4),
                                                      ),
                                                      child: const Text(
                                                        '必填',
                                                        style: TextStyle(
                                                          color: Colors.red,
                                                          fontSize: 10,
                                                        ),
                                                      ),
                                                    ),
                                                  const Spacer(),
                                                  if (entry.value is Map && entry.value['description'] != null)
                                                    Text(
                                                      entry.value['description'].toString(),
                                                      style: TextStyle(
                                                        color: Colors.grey[600],
                                                        fontSize: 12,
                                                      ),
                                                    )
                                                  else
                                                    Text(
                                                      entry.value.toString(),
                                                      style: TextStyle(
                                                        color: Colors.grey[600],
                                                        fontSize: 12,
                                                      ),
                                                    ),
                                                ],
                                              ),
                                            );
                                          })),
                                        ] else
                                          const Text(
                                            '无参数定义',
                                            style: TextStyle(
                                              fontStyle: FontStyle.italic,
                                              color: Colors.grey,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('关闭'),
                    ),
                  ),
                ],
              ),
            );
          }
        );
      },
    );
  }

  void _showDeleteConfirmation(McpService service) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('确认删除服务 ${service.name}'),
          content: Text('删除服务后，所有相关数据将被清除。'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () async {
                // 删除服务
                _services.remove(service);
                // 保存服务列表到存储
                await McpStorageService.saveMcpServices(_services);
                // 重新加载服务列表，确保显示最新数据
                await _loadServices();
                // 关闭对话框
                Navigator.of(context).pop();
              },
              child: const Text('删除'),
            ),
          ],
        );
      },
    );
  }
}