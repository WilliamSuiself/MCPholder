import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../models/mcp_service.dart';
import '../services/mcp_storage_service.dart';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import 'package:webview_flutter/webview_flutter.dart';

class TestServiceScreen extends StatefulWidget {
  const TestServiceScreen({super.key});

  @override
  State<TestServiceScreen> createState() => _TestServiceScreenState();
}

class _TestServiceScreenState extends State<TestServiceScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _urlController = TextEditingController();
  final TextEditingController _portController = TextEditingController();
  final TextEditingController _apiKeyController = TextEditingController();
  final TextEditingController _clientIdController = TextEditingController(
    text: 'remote-mcp-client',
  ); // 修改默认客户端ID

  // 添加工具相关控制器
  final TextEditingController _toolNameController = TextEditingController();
  final TextEditingController _toolDescriptionController =
      TextEditingController();
  final TextEditingController _toolParametersController =
      TextEditingController();

  // 添加参数相关控制器
  final List<TextEditingController> _paramNameControllers = [];
  final List<TextEditingController> _paramDescriptionControllers = [];
  final List<bool> _paramRequiredValues = [];

  // 当前编辑的参数列表
  List<Map<String, dynamic>> _currentParameters = [];
  bool _showParameterPanel = false;

  bool _isSecure = true;
  bool _isTesting = false;
  bool _testCompleted = false;
  bool _testSuccess = false;
  String _testMessage = '';

  // OAuth授权相关状态
  bool _needsOAuth = false;
  String? _codeVerifier;
  String? _codeChallenge;
  String? _accessToken;
  String? _refreshToken;
  bool _isAuthenticating = false;

  // 工具相关状态
  List<Map<String, dynamic>> _toolSchemas = []; // 添加工具列表
  bool _showToolPanel = false;
  bool _isSaving = false;
  bool _showReturnButton = false;
  bool _showSaveButton = false; // 新增保存按钮状态
  String? _sessionId; // SSE会话ID

  @override
  void dispose() {
    _nameController.dispose();
    _urlController.dispose();
    _portController.dispose();
    _apiKeyController.dispose();
    _clientIdController.dispose(); // 添加客户端ID控制器的释放
    _toolNameController.dispose();
    _toolDescriptionController.dispose();
    _toolParametersController.dispose();

    // 清理参数控制器
    for (var controller in _paramNameControllers) {
      controller.dispose();
    }
    for (var controller in _paramDescriptionControllers) {
      controller.dispose();
    }

    super.dispose();
  }

  void _toggleToolPanel() {
    setState(() {
      _showToolPanel = !_showToolPanel;
    });
  }

  void _toggleParameterPanel() {
    setState(() {
      _showParameterPanel = !_showParameterPanel;
      if (_showParameterPanel) {
        // 初始化一个空参数
        _addEmptyParameter();
      }
    });
  }

  void _addEmptyParameter() {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();

    setState(() {
      _paramNameControllers.add(nameController);
      _paramDescriptionControllers.add(descriptionController);
      _paramRequiredValues.add(true);
    });
  }

  void _removeParameter(int index) {
    setState(() {
      _paramNameControllers[index].dispose();
      _paramDescriptionControllers[index].dispose();

      _paramNameControllers.removeAt(index);
      _paramDescriptionControllers.removeAt(index);
      _paramRequiredValues.removeAt(index);
    });
  }

  void _saveParameters() {
    final parameters = <String, dynamic>{};
    final required = <String>[];

    for (int i = 0; i < _paramNameControllers.length; i++) {
      final name = _paramNameControllers[i].text.trim();
      final description = _paramDescriptionControllers[i].text.trim();

      if (name.isNotEmpty) {
        parameters[name] = description.isNotEmpty ? description : name;

        if (_paramRequiredValues[i]) {
          required.add(name);
        }
      }
    }

    setState(() {
      _currentParameters = [
        {'properties': parameters, 'required': required},
      ];
      _showParameterPanel = false;
    });
  }

  void _testConnection() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isTesting = true;
        _testCompleted = false;
        _testSuccess = false;
        _testMessage = '正在测试连接...';
        _toolSchemas = []; // 清空工具列表
      });
      
      final serviceUrl = _urlController.text.trim();
      if (serviceUrl.isEmpty) {
        setState(() {
          _isTesting = false;
          _testCompleted = true;
          _testSuccess = false;
          _testMessage = '请输入服务URL';
        });
        return;
      }
      
      try {
        // 确保URL不以斜杠结尾
        String baseUrl = serviceUrl;
        if (baseUrl.endsWith('/')) {
          baseUrl = baseUrl.substring(0, baseUrl.length - 1);
        }
        
        // 先测试连接，如果需要OAuth，会在测试连接过程中设置_needsOAuth标志
        _testConnectionWithEndpoint(baseUrl);
      } catch (e) {
        print('测试连接异常: $e');
        setState(() {
          _testMessage = '连接失败: $e';
          _testCompleted = true;
          _isTesting = false;
        });
      }
    }
  }

  void _testConnectionWithEndpoint(String url) async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isTesting = true;
        _testCompleted = false;
        _testSuccess = false;
        _testMessage = '正在连接到服务...';
        _needsOAuth = false;
      });

      // 确保URL不以斜杠结尾
      String updatedUrl = url;
      if (updatedUrl.endsWith('/')) {
        updatedUrl = updatedUrl.substring(0, updatedUrl.length - 1);
      }

      print('正在连接到服务: $updatedUrl');

      // 检查URL是否已经包含/sse路径
      final mcpBaseUrl = updatedUrl; // 保存不含/sse的基础URL，用于OAuth授权
      if (!updatedUrl.endsWith('/sse')) {
        updatedUrl = '$updatedUrl/sse';
      }

      print('正在连接到MCP端点: $updatedUrl');
      print('基础URL (不含/sse): $mcpBaseUrl');

      try {
        // 创建请求头
        final headers = {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        };

        // 如果有访问令牌，优先使用访问令牌
        if (_accessToken != null && _accessToken!.isNotEmpty) {
          // 确保访问令牌格式正确（应该是JWT格式）
          if (!_accessToken!.contains('.') ||
              _accessToken!.split('.').length != 3) {
            print('警告：访问令牌格式可能不正确，不是标准JWT格式');
          }
          headers['Authorization'] = 'Bearer $_accessToken';
          print(
            '使用访问令牌进行授权: ${_accessToken?.substring(0, math.min(10, _accessToken!.length))}...',
          );
        }
        // 如果有API密钥，添加到请求头
        else if (_apiKeyController.text.isNotEmpty) {
          final apiKey = _apiKeyController.text.trim();

          // 不要将API密钥作为访问令牌使用
          // Cloudflare MCP服务器期望的是通过OAuth流程获取的JWT格式令牌
          print('有API密钥，但不作为访问令牌使用，将启动OAuth授权流程');

          // 将API密钥添加为自定义头部，以防服务器支持这种方式
          headers['X-API-Key'] = apiKey;
        } else {
          print('警告：没有提供授权信息');
        }

        // 创建初始化消息
        final initMessage = {
          'type': 'init',
          'version': '1.0',
          'client': {'name': 'Flutter MCP Client', 'version': '1.0.0'},
        };

        print('请求头: $headers');
        print('初始化消息: $initMessage');

        // 发送POST请求初始化MCP连接
        final response = await http
            .post(
              Uri.parse(url),
              headers: headers,
              body: json.encode(initMessage),
            )
            .timeout(const Duration(seconds: 10)); // 增加超时时间

        print('响应状态码: ${response.statusCode}');
        print('响应头: ${response.headers}');
        print('响应体: ${response.body}');

        if (response.statusCode == 200) {
          // 连接成功
          setState(() {
            _isTesting = false;
            _testCompleted = true;
            _testSuccess = true;
            _testMessage = '连接成功！';
            _needsOAuth = false;
          });

          // 获取工具列表
          _fetchTools(url, _accessToken ?? '');
        } else if (response.statusCode == 401 || response.statusCode == 403) {
          // 需要授权
          print('收到401/403响应，可能需要OAuth授权');
          print('响应体: ${response.body}');

          // 检查错误信息是否明确指出需要OAuth
          final errorBody = response.body.toLowerCase();
          final bool needsOAuth =
              errorBody.contains("oauth") ||
              errorBody.contains("access token") ||
              errorBody.contains("invalid_token") ||
              errorBody.contains("authorization");

          setState(() {
            _isTesting = false;
            _testCompleted = true;
            _testSuccess = false;

            if (needsOAuth) {
              // 根据Cloudflare MCP文档，我们需要显示一个按钮让用户手动点击授权
              _testMessage = '需要OAuth授权。请点击下方的"启动OAuth授权"按钮进行授权。';
              _needsOAuth = true;
            } else {
              _testMessage = '授权失败: ${response.statusCode}\n${response.body}';
              _needsOAuth = false;
            }
          });
        } else {
          // 连接失败
          setState(() {
            _isTesting = false;
            _testCompleted = true;
            _testSuccess = false;
            _testMessage = '连接失败: ${response.statusCode}\n${response.body}';
          });
        }
      } catch (e) {
        print('测试连接时出错: $e');
        setState(() {
          _isTesting = false;
          _testCompleted = true;
          _testSuccess = false;
          _testMessage = '连接出错: $e';
        });

        // 尝试其他可能的端点
        _tryAlternativeEndpoint(url);
      }
    }
  }

  // 尝试备用MCP端点
  void _tryAlternativeEndpoint(String url) async {
    try {
      print('尝试备用MCP端点');

      // 检查URL是否已经包含/sse路径
      final baseUrl =
          url.endsWith('/sse') ? url.substring(0, url.length - 4) : url;

      print('基础URL: $baseUrl');

      // 尝试其他可能的MCP端点
      final endpoints = [
        baseUrl,
        '$baseUrl/mcp',
        '$baseUrl/v1/mcp',
        '$baseUrl/api/mcp',
      ];

      for (final endpoint in endpoints) {
        try {
          print('尝试连接到: $endpoint');

          final headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          };

          if (_apiKeyController.text.isNotEmpty) {
            headers['Authorization'] = _apiKeyController.text.trim();
          } else if (_accessToken != null) {
            headers['Authorization'] = 'Bearer $_accessToken';
          }

          // 创建MCP初始化消息
          final initMessage = {
            'type': 'init',
            'version': '1.0',
            'client': {'name': 'Flutter MCP Client', 'version': '1.0.0'},
          };

          print('工具列表请求消息: $initMessage');

          final response = await http
              .post(
                Uri.parse(endpoint),
                headers: headers,
                body: json.encode(initMessage),
              )
              .timeout(const Duration(seconds: 3)); // 缩短超时时间

          print('响应状态码: ${response.statusCode}');
          print('响应头: ${response.headers}');
          print('响应体: ${response.body}');

          if (response.statusCode == 200) {
            print('备用端点连接成功: $endpoint');
            setState(() {
              _testMessage += '\n备用端点连接成功: $endpoint';
            });

            // 尝试获取工具列表
            _fetchTools(endpoint, _accessToken ?? '');
            return;
          } else if (response.statusCode == 401 || response.statusCode == 403) {
            // 需要授权
            setState(() {
              _needsOAuth = true;
              _testMessage += '\n获取工具列表需要授权';
            });

            // 尝试启动OAuth流程
            _initiateOAuthFlow(url);
            return;
          }
        } catch (e) {
          print('尝试备用端点 $endpoint 失败: $e');
        }
      }

      // 如果所有备用端点都失败，尝试直接访问授权端点
      setState(() {
        _testMessage += '\n所有MCP端点连接失败，尝试启动OAuth授权流程...';
        _needsOAuth = true;
      });

      // 直接尝试启动OAuth流程
      _initiateOAuthFlow(url);
    } catch (e) {
      print('尝试备用端点出错: $e');
    }
  }

  // 处理工具列表
  void _processToolsList(List<dynamic> toolsList) {
    // 将工具列表转换为标准格式
    final standardizedTools = toolsList.map((tool) {
      if (tool is Map) {
        Map<String, dynamic> standardTool = Map<String, dynamic>.from(tool);
        
        // 确保工具有name和description字段
        if (!standardTool.containsKey('name')) {
          standardTool['name'] = standardTool['id'] ?? '未命名工具';
        }
        if (!standardTool.containsKey('description')) {
          standardTool['description'] = '无描述';
        }
        
        // 确保parameters字段格式正确
        if (!standardTool.containsKey('parameters')) {
          standardTool['parameters'] = {
            'type': 'object',
            'properties': {},
            'required': []
          };
        } else if (standardTool['parameters'] is Map && !standardTool['parameters'].containsKey('type')) {
          standardTool['parameters']['type'] = 'object';
        }
        
        return standardTool;
      }
      return <String, dynamic>{
        'name': '未知工具',
        'description': '无描述',
        'parameters': {
          'type': 'object',
          'properties': {},
          'required': []
        }
      };
    }).toList();
    
    setState(() {
      _toolSchemas = List<Map<String, dynamic>>.from(standardizedTools);
      _testMessage += '\n成功获取到 ${_toolSchemas.length} 个工具';
      for (var i = 0; i < _toolSchemas.length && i < 5; i++) {
        _testMessage += '\n - ${_toolSchemas[i]['name'] ?? '未命名工具'}';
      }
      if (_toolSchemas.length > 5) {
        _testMessage += '\n ... 等更多工具';
      }
      _needsOAuth = false;
      _testCompleted = true; // 标记测试已完成
      _showSaveButton = true; // 显示保存按钮
    });
  }

  // 获取工具列表
  Future<bool> _fetchTools(String baseUrl, String token) async {
    setState(() {
      _testMessage = '正在连接服务器...';
      _isTesting = true;
      _testSuccess = false;
      _showSaveButton = false;
    });

    print('尝试获取工具列表，基础URL: $baseUrl');
    
    // 首先尝试通过SSE连接获取工具列表
    final sseSuccess = await _fetchToolsViaSSE(baseUrl, token);
    if (sseSuccess) {
      print('通过SSE成功获取工具列表');
      return true;
    }
    
    print('SSE方式获取工具列表失败，尝试JSON-RPC方式');
    
    // 如果SSE方式失败，尝试通过JSON-RPC方式获取
    final jsonRpcSuccess = await _fetchToolsViaJsonRpc(baseUrl, token);
    if (jsonRpcSuccess) {
      print('通过JSON-RPC成功获取工具列表');
      return true;
    }
    
    print('所有方式都失败，无法获取工具列表');
    setState(() {
      _testMessage += '\n无法获取工具列表，请检查服务器配置和连接';
      _isTesting = false;
    });
    
    return false;
  }
  
  // 调用工具
  Future<Map<String, dynamic>> callTool(String toolName, Map<String, dynamic> params) async {
    try {
      // 确保baseUrl不包含多余的斜杠
      String baseUrl = _urlController.text;
      if (baseUrl.endsWith('/')) {
        baseUrl = baseUrl.substring(0, baseUrl.length - 1);
      }
      
      final toolsCallEndpoint = '$baseUrl/tools/call';
      print('调用工具: $toolName, 端点: $toolsCallEndpoint');
      
      // 创建请求头
      final headers = {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Authorization': 'Bearer $_accessToken',
      };
      
      // 创建请求体
      final requestBody = {
        'name': toolName,
        'arguments': params
      };
      
      print('请求体: $requestBody');
      
      final response = await http
          .post(
            Uri.parse(toolsCallEndpoint),
            headers: headers,
            body: json.encode(requestBody),
          )
          .timeout(const Duration(seconds: 30));
          
      print('工具调用响应状态码: ${response.statusCode}');
      print('工具调用响应头: ${response.headers}');
      print('工具调用响应体: ${response.body}');
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('工具调用失败: ${response.statusCode}');
      }
    } catch (e) {
      print('调用工具时出错: $e');
      throw e;
    }
  }

  void _resetForm() {
    _formKey.currentState?.reset();
    _nameController.clear();
    _urlController.clear();
    _portController.clear();
    _apiKeyController.clear();
    setState(() {
      _testCompleted = false;
      _toolSchemas = []; // 清空工具列表
    });
  }

  void _saveService() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isSaving = true;
      });

      try {
        // 创建MCP服务对象
        final service = McpService(
          name: _nameController.text.trim(),
          description: '通过测试连接添加的MCP服务',
          icon: FontAwesomeIcons.server,
          isActive: true,
          tools: _toolSchemas,
          isRemote: true,
          authUrl: _urlController.text.trim(),
          accessToken: _accessToken,
          refreshToken: _refreshToken,
          apiKey: _apiKeyController.text.trim(),
          clientId: _clientIdController.text.trim(),
        );

        print('保存服务: ${service.name}');
        print('服务URL: ${service.authUrl}');
        print('工具数量: ${service.tools.length}');

        // 保存到存储
        final success = await McpStorageService.saveMcpService(service);

        setState(() {
          _isSaving = false;
          if (success) {
            _showReturnButton = true;
            _testMessage += '\n服务已成功保存！工具列表已保存，可供AI大模型调用。';
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('服务已成功保存！'),
                backgroundColor: Colors.green,
              ),
            );
          } else {
            _testMessage += '\n保存服务失败';
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('保存服务失败'),
                backgroundColor: Colors.red,
              ),
            );
          }
        });
      } catch (e) {
        print('保存服务出错: $e');
        setState(() {
          _isSaving = false;
          _testMessage += '\n保存服务出错: $e';
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('保存服务出错: $e'),
              backgroundColor: Colors.red,
            ),
          );
        });
      }
    }
  }

  // 生成随机字符串
  String _generateRandomString(int length) {
    const chars = '0123456789abcdef'; // 只使用十六进制字符
    final random = Random();
    return String.fromCharCodes(
      List.generate(length, (index) => chars.codeUnitAt(random.nextInt(chars.length)))
    );
  }

  // 生成指定长度的十六进制字符串
  String _generateHexString(int length) {
    final random = Random();
    final hexChars = '0123456789abcdef';
    return List.generate(length, (_) => hexChars[random.nextInt(hexChars.length)]).join();
  }

  // 从code_verifier生成code_challenge
  String _generateCodeChallenge(String verifier) {
    final List<int> bytes = utf8.encode(verifier);
    final Digest digest = sha256.convert(bytes);
    return base64Url
        .encode(digest.bytes)
        .replaceAll('+', '-')
        .replaceAll('/', '_')
        .replaceAll('=', '');
  }

  // 启动OAuth授权流程
  void _initiateOAuthFlow(String baseUrl) async {
    if (_isAuthenticating) {
      print('已经在进行授权，忽略重复请求');
      return;
    }

    setState(() {
      _isAuthenticating = true;
      _testMessage += '\n正在启动OAuth授权流程...';
    });

    print('启动OAuth授权流程，基础URL: $baseUrl');

    try {
      // 确保URL不包含/sse路径
      String authBaseUrl = baseUrl;
      if (authBaseUrl.endsWith('/sse')) {
        authBaseUrl = authBaseUrl.substring(0, authBaseUrl.length - 4);
      }

      // 生成随机状态值，用于防止CSRF攻击
      final state = _generateRandomString(12);
      print('生成的state值: $state');

      // 生成PKCE代码验证器和挑战
      final codeVerifier = _generateRandomString(64);
      _codeVerifier = codeVerifier; // 保存代码验证器以便后续使用

      final codeChallenge = await _generateCodeChallenge(codeVerifier);
      print('生成的代码验证器: $codeVerifier');
      print('生成的代码挑战: $codeChallenge');

      // 构建重定向URI
      final redirectUri = 'http://localhost';
      print('重定向URI: $redirectUri');

      // 构建授权URL
      final authorizationUrl =
          '$authBaseUrl/authorize?'
          'response_type=code'
          '&client_id=${_clientIdController.text}' // 使用客户端ID
          '&redirect_uri=${Uri.encodeComponent(redirectUri)}'
          '&scope=mcp'
          '&state=$state'
          '&code_challenge=$codeChallenge'
          '&code_challenge_method=S256';

      print('授权URL: $authorizationUrl');

      // 显示WebView授权对话框
      _showWebViewAuthDialog(
        context,
        authorizationUrl,
        redirectUri,
        codeVerifier,
        authBaseUrl,
      );
    } catch (e) {
      print('启动OAuth授权流程时出错: $e');
      setState(() {
        _isAuthenticating = false;
        _testMessage += '\n授权已取消';
      });
    }
  }

  // 显示WebView授权对话框
  void _showWebViewAuthDialog(
    BuildContext context,
    String authUrl,
    String redirectUri,
    String codeVerifier,
    String baseUrl,
  ) {
    print('打开WebView授权对话框，URL: $authUrl');

    // 创建WebView控制器
    late final WebViewController controller;

    controller =
        WebViewController()
          ..setJavaScriptMode(JavaScriptMode.unrestricted)
          ..setNavigationDelegate(
            NavigationDelegate(
              onNavigationRequest: (NavigationRequest request) {
                print('WebView导航请求: ${request.url}');

                // 检查URL是否包含授权码
                if (request.url.contains('code=')) {
                  print('检测到包含授权码的URL: ${request.url}');

                  // 从URL中提取授权码
                  final uri = Uri.parse(request.url);
                  final code = uri.queryParameters['code'];

                  print('提取的授权码: $code');

                  if (code != null) {
                    // 关闭WebView对话框
                    Navigator.of(context).pop();

                    // 使用授权码交换访问令牌
                    _exchangeCodeForToken(
                      baseUrl,
                      code,
                      redirectUri,
                      codeVerifier,
                    );
                    return NavigationDecision.prevent;
                  }
                }

                // 允许所有其他导航
                return NavigationDecision.navigate;
              },
              onPageStarted: (String url) {
                print('WebView开始加载页面: $url');
              },
              onPageFinished: (String url) {
                print('WebView页面加载完成: $url');

                // 尝试注入JavaScript来自动填充表单或点击按钮
                controller.runJavaScript('''
              // 检查是否有错误信息
              const errorElement = document.querySelector('.error-message, .alert-error, [role="alert"]');
              if (errorElement) {
                console.log('发现错误信息: ' + errorElement.textContent);
              }
              
              // 输出页面标题和内容用于调试
              console.log('页面标题: ' + document.title);
              console.log('页面内容: ' + document.body.innerText);
            ''');
              },
            ),
          )
          ..loadRequest(Uri.parse(authUrl));

    // 显示对话框
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return WillPopScope(
          onWillPop: () async {
            // 确保在用户按返回键时清理WebView资源
            setState(() {
              _isAuthenticating = false;
            });
            return true;
          },
          child: AlertDialog(
            title: const Text('OAuth授权'),
            content: SizedBox(
              width: double.infinity,
              height: 500,
              child: Column(
                children: [
                  const Text(
                    '请在下方WebView中完成授权',
                    style: TextStyle(fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  Expanded(child: WebViewWidget(controller: controller)),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  // 关闭对话框
                  Navigator.of(context).pop();
                  // 重置授权状态
                  setState(() {
                    _isAuthenticating = false;
                    _testMessage += '\n授权已取消';
                  });

                  // 释放WebView资源
                  controller.clearCache();
                  controller.clearLocalStorage();
                },
                child: const Text('取消'),
              ),
            ],
          ),
        );
      },
    ).then((_) {
      // 确保在对话框关闭时清理WebView资源
      controller.clearCache();
      controller.clearLocalStorage();

      // 如果用户仍在授权过程中，重置状态
      if (_isAuthenticating) {
        setState(() {
          _isAuthenticating = false;
        });
      }
    });
  }

  // 使用授权码交换访问令牌
  Future<Map<String, dynamic>?> _exchangeCodeForToken(
    String baseUrl,
    String code,
    String redirectUri,
    String codeVerifier,
  ) async {
    try {
      final tokenEndpoint = '$baseUrl/token';
      print('令牌端点URL: $tokenEndpoint');

      // 构建注册请求体
      final requestBody = {
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirectUri,
        'client_id': _clientIdController.text, // 使用客户端ID
        'code_verifier': codeVerifier,
      };
      print('令牌请求体: $requestBody');

      // 创建请求头
      final headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      };

      if (_accessToken != null && _accessToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_accessToken';
        print('使用访问令牌进行客户端注册: ${_accessToken?.substring(0, math.min(10, _accessToken!.length))}...');
      } else {
        print('警告：没有访问令牌进行客户端注册，可能会导致401错误');
      }

      print('令牌请求头: $headers');

      // 将请求体转换为x-www-form-urlencoded格式
      final encodedBody = requestBody.entries
          .map(
            (e) =>
                '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}',
          )
          .join('&');
      print('编码后的请求体: $encodedBody');

      // 发送POST请求
      final response = await http.post(
        Uri.parse(tokenEndpoint),
        headers: headers,
        body: encodedBody,
      );

      print('令牌响应状态码: ${response.statusCode}');
      print('令牌响应头: ${response.headers}');
      print('令牌响应体: ${response.body}');

      if (response.statusCode == 200) {
        // 解析JSON响应
        final jsonResponse = jsonDecode(response.body);
        print('解析的令牌响应: $jsonResponse');

        // 获取访问令牌和刷新令牌
        setState(() {
          _accessToken = jsonResponse['access_token'];
          _refreshToken = jsonResponse['refresh_token'];
          _needsOAuth = false;
          _testMessage += '\n授权成功！获取到访问令牌。';
        });

        // 使用访问令牌测试连接
        _testWithAccessToken(baseUrl);

        return jsonResponse;
      } else {
        print('令牌交换失败: ${response.statusCode}, ${response.body}');
        setState(() {
          _testMessage += '\n授权失败: ${response.statusCode}, ${response.body}';
        });
        return null;
      }
    } catch (e) {
      print('令牌交换异常: $e');
      setState(() {
        _testMessage += '\n授权出错: $e';
      });
      return null;
    }
  }

  // 使用访问令牌测试连接
  Future<void> _testWithAccessToken(String baseUrl) async {
    try {
      print('使用访问令牌测试连接');
      setState(() {
        _testMessage += '\n尝试使用访问令牌连接...';
        _isTesting = true;
      });
      
      // 确保URL不包含多余的斜杠
      if (baseUrl.endsWith('/')) {
        baseUrl = baseUrl.substring(0, baseUrl.length - 1);
      }
      
      // 如果没有客户端ID，尝试注册
      if (_clientIdController.text.isEmpty) {
        await _registerClient(baseUrl);
      }
      
      // 生成一个会话ID - 只使用十六进制字符
      final sessionId = _generateHexString(64);
      _sessionId = sessionId;
      print('会话ID: $sessionId');
      
      // 首先尝试通过SSE连接获取工具
      bool sseSuccess = await _fetchToolsViaSSE(baseUrl, _accessToken ?? '');
      
      // 如果SSE方式失败，尝试通过JSON-RPC获取工具列表
      if (!sseSuccess) {
        bool jsonRpcSuccess = await _fetchToolsViaJsonRpc(baseUrl, _accessToken ?? '');
        
        // 如果JSON-RPC方式也失败，尝试直接获取工具列表
        if (!jsonRpcSuccess) {
          await _fetchTools(baseUrl, _accessToken ?? '');
        }
      }
      
    } catch (e) {
      print('使用访问令牌测试连接时出错: $e');
      setState(() {
        _testMessage += '\n测试连接时出错: $e';
        _isTesting = false;
      });
    }
  }
  
  // 通过SSE连接获取工具列表
  Future<bool> _fetchToolsViaSSE(String baseUrl, String token) async {
    try {
      print('尝试通过SSE连接获取工具列表');
      
      // 创建请求头
      final headers = {
        'Accept': 'text/event-stream',
        'Authorization': 'Bearer $token',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/134.0.0.0 Safari/537.36',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      };
      
      // 连接到SSE端点
      print('尝试SSE连接: $baseUrl/sse');
      
      try {
        // 使用HttpClient来处理SSE连接
        final client = HttpClient();
        client.connectionTimeout = const Duration(seconds: 10);
        
        final request = await client.getUrl(Uri.parse('$baseUrl/sse'));
        headers.forEach((key, value) {
          request.headers.set(key, value);
        });
        
        final response = await request.close().timeout(const Duration(seconds: 10));
        
        print('SSE连接响应状态码: ${response.statusCode}');
        
        if (response.statusCode == 200) {
          print('SSE连接成功');
          
          // 使用更低级别的方式处理SSE流
          final completer = Completer<bool>();
          String buffer = '';
          String? sessionId;
          
          response.transform(utf8.decoder).listen((data) {
            print('收到SSE数据块: $data');
            buffer += data;
            
            // 处理缓冲区中的完整行
            final lines = buffer.split('\n');
            buffer = lines.removeLast(); // 保留最后一个可能不完整的行
            
            for (int i = 0; i < lines.length; i++) {
              final line = lines[i].trim();
              if (line.isEmpty) continue;
              
              print('处理SSE行: $line');
              
              // 处理endpoint事件
              if (line == 'event: endpoint' && i + 1 < lines.length && lines[i + 1].startsWith('data:')) {
                final endpointUrl = lines[i + 1].substring(5).trim();
                print('检测到endpoint事件，URL: $endpointUrl');
                
                try {
                  final uri = Uri.parse(endpointUrl);
                  sessionId = uri.queryParameters['sessionId'];
                  
                  if (sessionId != null) {
                    print('从endpoint事件中获取会话ID: $sessionId');
                    _sessionId = sessionId;
                    
                    // 连接到消息端点
                    final messageEndpoint = '$baseUrl$endpointUrl';
                    print('尝试连接到消息端点: $messageEndpoint');
                    
                    // 不在这里发送请求，等待message事件
                  }
                } catch (e) {
                  print('解析endpoint URL失败: $e');
                }
                
                i++; // 跳过data行
                continue;
              }
              
              // 处理message事件
              if (line == 'event: message' && i + 1 < lines.length && lines[i + 1].startsWith('data:')) {
                final data = lines[i + 1].substring(5).trim();
                print('检测到message事件，数据: $data');
                
                try {
                  final jsonData = json.decode(data);
                  print('解析的message JSON数据: $jsonData');
                  
                  final toolsList = _extractToolsList(jsonData);
                  
                  if (toolsList != null && toolsList.isNotEmpty) {
                    print('从message事件中找到工具列表: $toolsList');
                    _processToolsList(toolsList);
                    
                    setState(() {
                      _testMessage += '\n成功从SSE消息中获取工具列表，找到${toolsList.length}个工具';
                      _testSuccess = true;
                      _showSaveButton = true;
                      _isTesting = false;
                    });
                    
                    completer.complete(true);
                    return;
                  }
                } catch (e) {
                  print('解析message数据失败: $e');
                }
                
                i++; // 跳过data行
                continue;
              }
            }
          }, 
          onError: (e) {
            print('SSE流错误: $e');
            if (!completer.isCompleted) {
              completer.complete(false);
            }
          }, 
          onDone: () {
            print('SSE流结束');
            
            // 如果获取了会话ID但没有获取到工具列表，尝试使用会话ID获取工具列表
            if (_sessionId != null && !completer.isCompleted) {
              _fetchToolsWithSessionId(baseUrl, token, _sessionId!).then((success) {
                if (!completer.isCompleted) {
                  completer.complete(success);
                }
              });
            } else if (!completer.isCompleted) {
              completer.complete(false);
            }
          });
          
          // 设置超时
          Future.delayed(const Duration(seconds: 20), () {
            if (!completer.isCompleted) {
              print('SSE连接超时');
              completer.complete(false);
            }
          });
          
          final result = await completer.future;
          if (result) return true;
          
          // 如果SSE连接成功但没有获取到工具列表，尝试其他方法
          client.close();
          return await _fetchToolsWithSessionId(baseUrl, token, _sessionId!);
        } else {
          print('SSE连接失败，状态码: ${response.statusCode}');
          client.close();
        }
      } catch (e) {
        print('SSE连接出错: $e');
      }
      
      return false;
    } catch (e) {
      print('通过SSE获取工具列表时出错: $e');
      return false;
    }
  }
  
  // 使用会话ID获取工具列表
  Future<bool> _fetchToolsWithSessionId(String baseUrl, String token, String sessionId) async {
    print('尝试使用会话ID获取工具列表: $sessionId');
    
    try {
      // 消息端点
      final messageEndpoint = '$baseUrl/sse/message?sessionId=$sessionId';
      print('尝试连接消息端点: $messageEndpoint');
      
      // 使用HttpClient来处理SSE连接
      final client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 10);
      
      final request = await client.getUrl(Uri.parse(messageEndpoint));
      final headers = {
        'Accept': 'text/event-stream',
        'Authorization': 'Bearer $token',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      };
      
      headers.forEach((key, value) {
        request.headers.set(key, value);
      });
      
      final response = await request.close().timeout(const Duration(seconds: 10));
      
      print('消息端点响应状态码: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        print('消息端点连接成功');
        
        // 使用更低级别的方式处理SSE流
        final completer = Completer<bool>();
        String buffer = '';
        
        response.transform(utf8.decoder).listen((data) {
          print('收到消息端点数据块: $data');
          buffer += data;
          
          // 处理缓冲区中的完整行
          final lines = buffer.split('\n');
          buffer = lines.removeLast(); // 保留最后一个可能不完整的行
          
          for (int i = 0; i < lines.length; i++) {
            final line = lines[i].trim();
            if (line.isEmpty) continue;
            
            print('处理消息端点行: $line');
            
            // 处理message事件
            if (line == 'event: message' && i + 1 < lines.length && lines[i + 1].startsWith('data:')) {
              final data = lines[i + 1].substring(5).trim();
              print('检测到message事件，数据: $data');
              
              try {
                final jsonData = json.decode(data);
                print('解析的message JSON数据: $jsonData');
                
                final toolsList = _extractToolsList(jsonData);
                
                if (toolsList != null && toolsList.isNotEmpty) {
                  print('从message事件中找到工具列表: $toolsList');
                  _processToolsList(toolsList);
                  
                  setState(() {
                    _testMessage += '\n成功从消息端点获取工具列表，找到${toolsList.length}个工具';
                    _testSuccess = true;
                    _showSaveButton = true;
                    _isTesting = false;
                  });
                  
                  completer.complete(true);
                  return;
                }
              } catch (e) {
                print('解析message数据失败: $e');
              }
              
              i++; // 跳过data行
              continue;
            }
          }
        }, 
        onError: (e) {
          print('消息端点流错误: $e');
          if (!completer.isCompleted) {
            completer.complete(false);
          }
        }, 
        onDone: () {
          print('消息端点流结束');
          if (!completer.isCompleted) {
            completer.complete(false);
          }
        });
        
        // 设置超时
        Future.delayed(const Duration(seconds: 20), () {
          if (!completer.isCompleted) {
            print('消息端点连接超时');
            completer.complete(false);
          }
        });
        
        final result = await completer.future;
        client.close();
        return result;
      } else {
        print('消息端点连接失败，状态码: ${response.statusCode}');
        client.close();
      }
      
      // 如果SSE连接失败，尝试JSON-RPC
      return await _fetchToolsViaJsonRpc(baseUrl, token);
    } catch (e) {
      print('使用会话ID获取工具列表失败: $e');
      return false;
    }
  }
  
  // 通过JSON-RPC获取工具列表
  Future<bool> _fetchToolsViaJsonRpc(String baseUrl, String token) async {
    try {
      print('尝试通过JSON-RPC获取工具列表');
      
      // 创建请求头
      final headers = {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Authorization': 'Bearer $token',
      };
      
      // 创建JSON-RPC请求
      final jsonRpcRequest = {
        'jsonrpc': '2.0',
        'method': 'tools/list',
        'params': {},
        'id': '1'
      };
      
      print('JSON-RPC请求头: $headers');
      
      // 尝试向消息端点发送请求
      if (_sessionId != null) {
        final messageEndpoint = '$baseUrl/sse/message?sessionId=$_sessionId';
        print('尝试向消息端点发送JSON-RPC请求: $messageEndpoint');
        
        try {
          final response = await http.post(
            Uri.parse(messageEndpoint),
            headers: headers,
            body: json.encode(jsonRpcRequest),
          ).timeout(const Duration(seconds: 10));
          
          print('JSON-RPC响应状态码: ${response.statusCode}');
          
          if (response.statusCode == 200) {
            print('JSON-RPC响应体: ${response.body}');
            
            final result = _processJsonRpcResponse(response.body);
            if (result) return true;
          }
        } catch (e) {
          print('JSON-RPC请求失败: $e');
        }
      }
      
      return false;
    } catch (e) {
      print('通过JSON-RPC获取工具列表时出错: $e');
      return false;
    }
  }
  
  // 处理JSON-RPC响应
  bool _processJsonRpcResponse(String responseBody) {
    try {
      final responseData = json.decode(responseBody);
      
      // 尝试提取工具列表
      List<dynamic>? toolsList;
      if (responseData is Map) {
        // 直接在顶层查找
        if (responseData['tools'] is List) {
          toolsList = responseData['tools'];
        } 
        // 在result字段中查找
        else if (responseData['result'] is Map && responseData['result']['tools'] is List) {
          toolsList = responseData['result']['tools'];
        } 
        // result字段本身是列表
        else if (responseData['result'] is List) {
          toolsList = responseData['result'];
        }
        // 在data字段中查找
        else if (responseData['data'] is Map && responseData['data']['tools'] is List) {
          toolsList = responseData['data']['tools'];
        }
        else if (responseData['data'] is List) {
          toolsList = responseData['data'];
        }
        // 在response字段中查找
        else if (responseData['response'] is Map && responseData['response']['tools'] is List) {
          toolsList = responseData['response']['tools'];
        }
        else if (responseData['response'] is List) {
          toolsList = responseData['response'];
        }
      } 
      // 响应本身是列表
      else if (responseData is List) {
        toolsList = responseData;
      }
      
      if (toolsList != null && toolsList.isNotEmpty) {
        print('从响应中找到工具列表: $toolsList');
        _processToolsList(toolsList);
        
        final toolsCount = toolsList.length;
        setState(() {
          _testMessage += '\n成功获取工具列表，找到$toolsCount个工具';
          _testSuccess = true;
          _showSaveButton = true;
          _isTesting = false;
        });
        
        return true;
      }
      
      return false;
    } catch (e) {
      print('解析响应失败: $e');
      return false;
    }
  }
  
  // 从JSON数据中提取工具列表
  List<dynamic>? _extractToolsList(dynamic jsonData) {
    List<dynamic>? toolsList;
    
    // 检查result.tools字段
    if (jsonData is Map && 
        jsonData['result'] is Map && 
        jsonData['result']['tools'] is List) {
      toolsList = jsonData['result']['tools'];
      print('在result.tools字段中找到工具列表: $toolsList');
    }
    // 检查tools字段
    else if (jsonData is Map && jsonData['tools'] is List) {
      toolsList = jsonData['tools'];
      print('在tools字段中找到工具列表: $toolsList');
    }
    // 检查result字段（如果是列表）
    else if (jsonData is Map && 
             jsonData['result'] is List) {
      toolsList = jsonData['result'];
      print('在result字段中找到工具列表: $toolsList');
    }
    // 检查data字段
    else if (jsonData is Map && 
             jsonData['data'] is Map && 
             jsonData['data']['tools'] is List) {
      toolsList = jsonData['data']['tools'];
      print('在data.tools字段中找到工具列表: $toolsList');
    }
    else if (jsonData is Map && 
             jsonData['data'] is List) {
      toolsList = jsonData['data'];
      print('在data字段中找到工具列表: $toolsList');
    }
    // 检查response字段
    else if (jsonData is Map && 
             jsonData['response'] is Map && 
             jsonData['response']['tools'] is List) {
      toolsList = jsonData['response']['tools'];
      print('在response.tools字段中找到工具列表: $toolsList');
    }
    else if (jsonData is Map && 
             jsonData['response'] is List) {
      toolsList = jsonData['response'];
      print('在response字段中找到工具列表: $toolsList');
    }
    // 如果jsonData本身是列表
    else if (jsonData is List) {
      toolsList = jsonData;
      print('JSON数据本身是工具列表: $toolsList');
    }
    
    return toolsList;
  }
  
  void _addTool() {
    final toolName = _toolNameController.text.trim();
    final toolDescription = _toolDescriptionController.text.trim();

    if (toolName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('工具名称不能为空'), backgroundColor: Colors.red),
      );
      return;
    }

    Map<String, dynamic> parameters = {};
    List<String> required = [];

    if (_currentParameters.isNotEmpty) {
      parameters = _currentParameters[0]['properties'];
      required = List<String>.from(_currentParameters[0]['required']);
    }

    setState(() {
      _toolSchemas.add({
        'name': toolName,
        'description': toolDescription,
        'parameters': {
          'type': 'object',
          'properties': parameters,
          'required': required,
        },
      });
    });

    _toolNameController.clear();
    _toolDescriptionController.clear();
    _currentParameters = [];

    // 清理参数控制器
    for (var controller in _paramNameControllers) {
      controller.dispose();
    }
    for (var controller in _paramDescriptionControllers) {
      controller.dispose();
    }
    _paramNameControllers.clear();
    _paramDescriptionControllers.clear();
    _paramRequiredValues.clear();

    // 隐藏工具添加面板
    _toggleToolPanel();
  }

  void _removeTool(int index) {
    setState(() {
      _toolSchemas.removeAt(index);
    });
  }

  // 客户端注册
  Future<String?> _registerClient(String baseUrl) async {
    try {
      // 确保使用主域名而不是/sse路径
      String registrationUrl = baseUrl;
      if (registrationUrl.endsWith('/sse')) {
        registrationUrl = registrationUrl.substring(0, registrationUrl.length - 4);
      }

      final registrationEndpoint = '$registrationUrl/register';
      print('注册端点URL: $registrationEndpoint');

      // 构建注册请求体
      final requestBody = {
        'redirect_uris': ['http://localhost'],
        'client_name': 'MCP Flutter Client',
        'client_uri': 'http://localhost',
        'grant_types': ['authorization_code', 'refresh_token'],
        'response_types': ['code'],
        'token_endpoint_auth_method': 'none',
      };
      print('注册请求体: $requestBody');

      // 创建请求头
      final headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

      if (_accessToken != null && _accessToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_accessToken';
        print('使用访问令牌进行客户端注册: ${_accessToken?.substring(0, math.min(10, _accessToken!.length))}...');
      } else {
        print('警告：没有访问令牌进行客户端注册，可能会导致401错误');
      }

      print('注册请求头: $headers');

      // 发送POST请求
      final response = await http.post(
        Uri.parse(registrationEndpoint),
        headers: headers,
        body: jsonEncode(requestBody),
      );

      print('注册响应状态码: ${response.statusCode}');
      print('注册响应头: ${response.headers}');
      print('注册响应体: ${response.body}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        // 解析JSON响应
        final jsonResponse = jsonDecode(response.body);
        print('解析的注册响应: $jsonResponse');

        // 获取客户端ID
        final clientId = jsonResponse['client_id'];
        if (clientId != null) {
          print('成功获取客户端ID: $clientId');
          setState(() {
            _testMessage += '\n成功注册客户端ID: $clientId';
          });
          return clientId;
        } else {
          print('响应中没有客户端ID');
          setState(() {
            _testMessage += '\n注册响应中没有客户端ID';
          });
          return null;
        }
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        // 需要授权才能注册客户端
        print('客户端注册需要授权: ${response.statusCode}, ${response.body}');
        setState(() {
          _needsOAuth = true;
          _testMessage += '\n客户端注册需要OAuth授权，请先完成授权流程';
        });
        return null;
      } else {
        print('客户端注册失败: ${response.statusCode}, ${response.body}');
        setState(() {
          _testMessage += '\n客户端注册失败: ${response.statusCode}, ${response.body}';
        });
        return null;
      }
    } catch (e) {
      print('注册客户端异常: $e');
      setState(() {
        _testMessage += '\n注册客户端异常: $e';
      });
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('测试MCP服务'),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '添加新的MCP服务',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  '请提供MCP服务的详细信息以便进行连接测试。',
                  style: TextStyle(color: Colors.black87),
                ),
                const SizedBox(height: 24),
                _buildTextField(
                  controller: _nameController,
                  label: '服务名称',
                  icon: Icons.label,
                  hint: '例如：Gmail、GitHub等',
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return '请输入服务名称';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: _urlController,
                  label: '服务URL',
                  icon: Icons.link,
                  hint: 'https://api.example.com',
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return '请输入服务URL';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: _portController,
                  label: '端口 (可选)',
                  icon: Icons.settings_ethernet,
                  hint: '例如：8080、443等',
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: _apiKeyController,
                  label: 'API密钥',
                  icon: Icons.vpn_key,
                  obscureText: _isSecure,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isSecure ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _isSecure = !_isSecure;
                      });
                    },
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return '请输入API密钥';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                _buildTextField(
                  controller: _clientIdController,
                  label: '客户端ID',
                  icon: Icons.person,
                  hint: '例如：mcp-client',
                ),
                const SizedBox(height: 8),
                ElevatedButton.icon(
                  icon: const Icon(Icons.app_registration),
                  label: const Text('注册客户端获取ID'),
                  onPressed: () async {
                    // 构建服务URL
                    String url = _urlController.text.trim();
                    if (!url.startsWith('http://') && !url.startsWith('https://')) {
                      url = 'https://$url';
                    }

                    if (_portController.text.isNotEmpty) {
                      url += ":${_portController.text.trim()}";
                    }

                    print('点击了注册客户端按钮，服务URL: $url');
                    setState(() {
                      _testMessage = '正在注册客户端...';
                      _testCompleted = false;
                    });

                    try {
                      // 直接注册客户端
                      final clientId = await _registerClient(url);
                      if (clientId != null) {
                        // 更新客户端ID
                        setState(() {
                          _clientIdController.text = clientId;
                          _testMessage = '注册成功！获取到客户端ID: $clientId';
                          _testCompleted = true;
                        });
                      } else {
                        setState(() {
                          _testMessage = '客户端注册失败';
                          _testCompleted = true;
                        });
                      }
                    } catch (e) {
                      print('注册客户端异常: $e');
                      setState(() {
                        _testMessage = '注册客户端出错: $e';
                        _testCompleted = true;
                      });
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                    foregroundColor: Colors.black87,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                ),
                const SizedBox(height: 32),
                if (_testCompleted)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _testSuccess ? Colors.green[50] : Colors.red[50],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _testSuccess ? Colors.green : Colors.red,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          _testSuccess ? Icons.check_circle : Icons.error,
                          color: _testSuccess ? Colors.green : Colors.red,
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Text(
                            _testMessage,
                            style: TextStyle(
                              color: _testSuccess ? Colors.green : Colors.red,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _isTesting ? null : _testConnection,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child:
                            _isTesting
                                ? const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                              Colors.white,
                                            ),
                                      ),
                                    ),
                                    SizedBox(width: 12),
                                    Text('测试中...'),
                                  ],
                                )
                                : const Text('测试连接'),
                      ),
                    ),
                    
                    // 当获取到工具后显示保存按钮
                    if (_showSaveButton)
                      const SizedBox(width: 8),
                    if (_showSaveButton)
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: Icon(
                            _isSaving ? Icons.hourglass_empty : Icons.save,
                          ),
                          label: Text(_isSaving ? '保存中...' : '保存服务'),
                          onPressed: _isSaving ? null : _saveService,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                  ],
                ),

                // 如果测试成功，显示工具相关UI
                if (_testCompleted && _testSuccess) ...[
                  const SizedBox(height: 32),
                  const Text(
                    'MCP工具配置',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigo,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    '添加该MCP服务提供的工具，使AI助手能够使用这些功能',
                    style: TextStyle(color: Colors.black87),
                  ),
                  const SizedBox(height: 16),

                  // 添加手动搜索工具按钮
                  ElevatedButton.icon(
                    icon: const Icon(Icons.search),
                    label: const Text('搜索工具列表'),
                    onPressed: () {
                      setState(() {
                        _testMessage += '\n正在搜索工具列表...';
                      });
                      
                      // 获取基础URL
                      String url = _urlController.text.trim();
                      if (!url.startsWith('http://') && !url.startsWith('https://')) {
                        url = 'https://$url';
                      }
                      
                      if (_portController.text.isNotEmpty) {
                        url += ":${_portController.text.trim()}";
                      }
                      
                      // 确保URL不以斜杠结尾
                      if (url.endsWith('/')) {
                        url = url.substring(0, url.length - 1);
                      }
                      
                      // 调用工具搜索方法
                      _fetchTools(url, _accessToken ?? '');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 已添加的工具列表
                  if (_toolSchemas.isNotEmpty) ...[
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _toolSchemas.length,
                      itemBuilder: (context, index) {
                        final tool = _toolSchemas[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: ListTile(
                            leading: const Icon(
                              Icons.build,
                              color: Colors.indigo,
                            ),
                            title: Text(tool['name']),
                            subtitle: Text(tool['description'] ?? '无描述'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _removeTool(index),
                              tooltip: '删除工具',
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                  ],

                  // 添加工具UI
                  if (_showToolPanel) ...[
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[300]!),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            '添加新工具',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 16),
                          _buildTextField(
                            controller: _toolNameController,
                            label: '工具名称',
                            icon: Icons.build,
                            hint: '例如：sendEmail, searchWeb',
                          ),
                          const SizedBox(height: 12),
                          _buildTextField(
                            controller: _toolDescriptionController,
                            label: '工具描述',
                            icon: Icons.description,
                            hint: '描述该工具的功能...',
                          ),
                          const SizedBox(height: 16),

                          // 参数管理部分
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    '参数定义',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.indigo,
                                    ),
                                  ),
                                  if (_currentParameters.isEmpty)
                                    TextButton.icon(
                                      icon: const Icon(Icons.add, size: 16),
                                      label: const Text('添加参数'),
                                      onPressed: _toggleParameterPanel,
                                      style: TextButton.styleFrom(
                                        foregroundColor: Colors.indigo,
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 8),

                              if (_currentParameters.isNotEmpty) ...[
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.indigo.withOpacity(0.05),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: Colors.indigo.withOpacity(0.2),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text(
                                            '已定义参数',
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.indigo,
                                            ),
                                          ),
                                          TextButton.icon(
                                            icon: const Icon(
                                              Icons.edit,
                                              size: 16,
                                            ),
                                            label: const Text('编辑'),
                                            onPressed: _toggleParameterPanel,
                                            style: TextButton.styleFrom(
                                              foregroundColor: Colors.indigo,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      ...(_currentParameters[0]['properties']
                                              as Map<String, dynamic>)
                                          .entries
                                          .map((entry) {
                                            final isRequired =
                                                (_currentParameters[0]['required']
                                                        as List)
                                                    .contains(entry.key);
                                            return Padding(
                                              padding: const EdgeInsets.only(
                                                bottom: 4,
                                              ),
                                              child: Row(
                                                children: [
                                                  Text(
                                                    entry.key,
                                                    style: const TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  if (isRequired)
                                                    Container(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            horizontal: 6,
                                                            vertical: 2,
                                                          ),
                                                      decoration: BoxDecoration(
                                                        color: Colors.red
                                                            .withOpacity(0.1),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              4,
                                                            ),
                                                      ),
                                                      child: const Text(
                                                        '必填',
                                                        style: TextStyle(
                                                          color: Colors.red,
                                                          fontSize: 10,
                                                        ),
                                                      ),
                                                    ),
                                                  const Spacer(),
                                                  Text(
                                                    entry.value.toString(),
                                                    style: TextStyle(
                                                      color: Colors.grey[600],
                                                      fontSize: 12,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          })
                                          .toList(),
                                    ],
                                  ),
                                ),
                              ] else if (!_showParameterPanel) ...[
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.grey[200],
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  width: double.infinity,
                                  child: const Text(
                                    '未定义参数',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                ),
                              ],

                              if (_showParameterPanel) ...[
                                const SizedBox(height: 12),
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: Colors.grey[300]!,
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text(
                                            '编辑参数',
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          IconButton(
                                            icon: const Icon(
                                              Icons.add_circle,
                                              color: Colors.indigo,
                                            ),
                                            onPressed: _addEmptyParameter,
                                            tooltip: '添加参数',
                                            iconSize: 20,
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 12),

                                      // 参数列表
                                      for (
                                        int i = 0;
                                        i < _paramNameControllers.length;
                                        i++
                                      ) ...[
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Expanded(
                                              flex: 3,
                                              child: TextField(
                                                controller:
                                                    _paramNameControllers[i],
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: '参数名称',
                                                  border:
                                                      OutlineInputBorder(),
                                                  contentPadding:
                                                      EdgeInsets.symmetric(
                                                        horizontal: 12,
                                                        vertical: 8,
                                                      ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              flex: 4,
                                              child: TextField(
                                                controller:
                                                    _paramDescriptionControllers[i],
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: '描述',
                                                  border:
                                                      OutlineInputBorder(),
                                                  contentPadding:
                                                      EdgeInsets.symmetric(
                                                        horizontal: 12,
                                                        vertical: 8,
                                                      ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Column(
                                              children: [
                                                Checkbox(
                                                  value:
                                                      _paramRequiredValues[i],
                                                  onChanged: (value) {
                                                    setState(() {
                                                      _paramRequiredValues[i] =
                                                          value ?? true;
                                                    });
                                                  },
                                                ),
                                                const Text(
                                                  '必填',
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            IconButton(
                                              icon: const Icon(
                                                Icons.delete,
                                                color: Colors.red,
                                              ),
                                              onPressed:
                                                  () => _removeParameter(i),
                                              tooltip: '删除参数',
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8),
                                      ],

                                      const SizedBox(height: 16),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          TextButton(
                                            onPressed: () {
                                              setState(() {
                                                _showParameterPanel = false;
                                              });
                                            },
                                            child: const Text('取消'),
                                          ),
                                          const SizedBox(width: 8),
                                          ElevatedButton(
                                            onPressed: _saveParameters,
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.indigo,
                                              foregroundColor: Colors.white,
                                            ),
                                            child: const Text('保存参数'),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),

                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: _toggleToolPanel,
                                child: const Text('取消'),
                              ),
                              const SizedBox(width: 8),
                              ElevatedButton(
                                onPressed: _addTool,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.indigo,
                                  foregroundColor: Colors.white,
                                ),
                                child: const Text('添加工具'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ] else ...[
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.add),
                        label: const Text('添加工具'),
                        onPressed: _toggleToolPanel,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.indigo,
                          side: const BorderSide(color: Colors.indigo),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isSaving ? null : _saveService,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child:
                          _isSaving
                              ? const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 12),
                                  Text('保存中...'),
                                ],
                              )
                              : const Text('保存MCP服务'),
                    ),
                  ),
                ],

                if (!_testCompleted || !_testSuccess) ...[
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _resetForm,
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.indigo,
                            side: const BorderSide(color: Colors.indigo),
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text('重置'),
                        ),
                      ),
                    ],
                  ),
                ],

                // 如果需要OAuth授权，显示授权按钮
                if (_needsOAuth) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.security, color: Colors.blue),
                            const SizedBox(width: 8),
                            Text(
                              'OAuth授权',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.blue,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '该服务需要OAuth授权。点击下方按钮启动授权流程。',
                          style: TextStyle(color: Colors.blue[800]),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: Icon(Icons.login),
                            label: Text(
                              _isAuthenticating ? '授权中...' : '启动OAuth授权',
                            ),
                            onPressed:
                                _isAuthenticating
                                    ? null
                                    : () {
                                      // 构建服务URL
                                      String url = _urlController.text.trim();
                                      if (!url.startsWith('http://') &&
                                          !url.startsWith('https://')) {
                                        url = 'https://$url';
                                      }

                                      if (_portController.text.isNotEmpty) {
                                        url +=
                                            ":${_portController.text.trim()}";
                                      }

                                      print('点击了OAuth授权按钮，启动授权流程，服务URL: $url');
                                      _initiateOAuthFlow(url);
                                    },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                        if (_accessToken != null) ...[
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              const SizedBox(width: 8),
                              Text(
                                '已获取OAuth访问令牌',
                                style: TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ],

                // 测试成功后显示保存按钮的提示信息
                if (_testCompleted && _testSuccess) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green[50],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.green),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.check_circle, color: Colors.green),
                            const SizedBox(width: 8),
                            Text(
                              '连接测试成功',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '您已成功连接到MCP服务，现在可以保存此服务。',
                          style: TextStyle(color: Colors.green[800]),
                        ),
                        if (_accessToken != null) ...[
                          const SizedBox(height: 8),
                          Text(
                            '已获取OAuth访问令牌，授权信息将被保存。',
                            style: TextStyle(
                              color: Colors.green[800],
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: Icon(
                              _isSaving ? Icons.hourglass_empty : Icons.save,
                            ),
                            label: Text(_isSaving ? '保存中...' : '保存MCP服务'),
                            onPressed: _isSaving ? null : _saveService,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // 如果保存成功，显示返回按钮
                if (_showReturnButton) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('返回'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    bool obscureText = false,
    Widget? suffixIcon,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.indigo,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(icon, color: Colors.indigo),
            suffixIcon: suffixIcon,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[300]!),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[300]!),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.indigo),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.red),
            ),
            filled: true,
            fillColor: Colors.grey[50],
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
          ),
          validator: validator,
        ),
      ],
    );
  }
}
