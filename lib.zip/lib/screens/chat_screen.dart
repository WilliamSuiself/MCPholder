import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:convert' show utf8;
import '../models/mcp_service.dart';
import '../services/mcp_storage_service.dart';
import '../config/api_config.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [];
  bool _isTyping = false;
  String _selectedModel = 'Claude 3.7 Sonnet';
  bool _extendedReasoning = false; // 新增：混合推理模式开关
  
  // MCP服务和工具相关状态
  List<McpService> _availableMcpServices = [];
  bool _enableTools = true; // 默认启用工具
  List<Map<String, dynamic>> _activeTools = [];
  Map<String, dynamic>? _currentToolCall;
  String? _currentToolCallId;
  bool _isExecutingTool = false;

  final List<ModelOption> _availableModels = [
    ModelOption(
      name: 'Claude 3.7 Sonnet', 
      id: 'anthropic/claude-3.7-sonnet',
      description: '先进的大语言模型，具有增强的推理和编码能力，支持200K上下文',
      inputPrice: '0.003', // $3/M tokens
      outputPrice: '0.015', // $15/M tokens
      imagePrice: '0.0048', // $4.8/K images
    ),
    ModelOption(
      name: 'Claude 3 Opus',
      id: 'anthropic/claude-3-opus',
      description: 'Anthropic的最强大模型，适合复杂任务',
      inputPrice: '0.015',
      outputPrice: '0.075',
      imagePrice: '0.004',
    ),
    ModelOption(
      name: 'GPT-4o',
      id: 'openai/gpt-4o',
      description: 'OpenAI的多模态模型，具有强大的视觉理解能力',
      inputPrice: '0.005',
      outputPrice: '0.015',
      imagePrice: '0.00',
    ),
    ModelOption(
      name: 'Gemini 1.5 Pro',
      id: 'google/gemini-1.5-pro',
      description: 'Google的多模态模型，具有长上下文理解能力',
      inputPrice: '0.0005',
      outputPrice: '0.0015',
      imagePrice: '0.0025',
    ),
  ];

  // 使用配置文件中的API密钥和端点
  final String _apiKey = ApiConfig.openRouterApiKey;
  final String _endpoint = ApiConfig.openRouterEndpoint;
  
  @override
  void initState() {
    super.initState();
    _loadMcpServices();
  }
  
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 每次页面可见时重新加载MCP服务
    _loadMcpServices();
  }
  
  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }
  
  // 从存储加载MCP服务
  Future<void> _loadMcpServices() async {
    try {
      // 从存储加载服务
      final services = await McpStorageService.loadMcpServices();
      
      setState(() {
        _availableMcpServices = services;
        _updateActiveTools();
      });
    } catch (e) {
      print('加载MCP服务失败: $e');
      // 出错时使用默认服务
      setState(() {
        _availableMcpServices = [
          McpService(
            name: 'Gmail',
            description: '发送和管理电子邮件',
            isActive: true,
            icon: FontAwesomeIcons.envelope,
            tools: [
              {
                'name': 'sendEmail',
                'description': '发送电子邮件',
                'parameters': {
                  'type': 'object',
                  'properties': {
                    'to': {'type': 'string', 'description': '收件人'},
                    'subject': {'type': 'string', 'description': '邮件主题'},
                    'body': {'type': 'string', 'description': '邮件内容'},
                  },
                  'required': ['to', 'subject'],
                }
              },
              {
                'name': 'readEmails',
                'description': '读取收件箱邮件',
                'parameters': {
                  'type': 'object',
                  'properties': {
                    'count': {'type': 'integer', 'description': '读取数量'},
                    'filter': {'type': 'string', 'description': '过滤条件（可选）'}
                  }
                }
              }
            ],
          ),
          McpService(
            name: 'Weather',
            description: '查询天气信息',
            isActive: true,
            icon: FontAwesomeIcons.cloud,
            tools: [
              {
                'name': 'getWeather',
                'description': '获取指定城市的天气信息',
                'parameters': {
                  'type': 'object',
                  'properties': {
                    'city': {'type': 'string', 'description': '城市名称'},
                    'days': {'type': 'integer', 'description': '天数（可选，默认1天）'}
                  },
                  'required': ['city']
                }
              }
            ],
          ),
        ];
        _updateActiveTools();
      });
    }
  }
  
  // 更新活跃的工具列表
  void _updateActiveTools() {
    _activeTools = [];
    for (var service in _availableMcpServices) {
      if (service.isActive) {
        for (var tool in service.tools) {
          _activeTools.add({
            ...tool,
            'service': service.name,
          });
        }
      }
    }
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.trim().isEmpty) {
      return;
    }
    
    final userMessage = _messageController.text.trim();
    _messageController.clear();
    
    setState(() {
      _messages.add(
        ChatMessage(
          text: userMessage,
          isUser: true,
        ),
      );
      _isTyping = true;
    });
    
    try {
      // 准备消息历史
      final List<Map<String, dynamic>> messages = [];
      
      // 添加历史消息
      for (final message in _messages) {
        if (message.isTool) continue; // 跳过工具消息
        
        messages.add({
          'role': message.isUser ? 'user' : 'assistant',
          'content': message.text,
        });
      }
      
      // 构建请求体
      final Map<String, dynamic> requestBody = {
        'model': _availableModels.firstWhere((model) => model.name == _selectedModel).id,
        'messages': messages,
      };
      
      // 如果有活跃工具，添加工具信息
      if (_activeTools.isNotEmpty) {
        final tools = _activeTools.map((tool) {
          // 解析参数
          Map<String, dynamic> parameters = {};
          
          if (tool.containsKey('parameters') && tool['parameters'] != null) {
            final params = tool['parameters'];
            
            if (params is Map) {
              // 直接使用Map类型的参数
              final properties = <String, dynamic>{};
              final required = <String>[];
              
              if (params.containsKey('properties') && params['properties'] is Map) {
                params['properties'].forEach((key, value) {
                  properties[key] = {
                    'type': value['type'] ?? 'string',
                    'description': value['description'] ?? '',
                  };
                  
                  if (params.containsKey('required') && 
                      params['required'] is List && 
                      (params['required'] as List).contains(key)) {
                    required.add(key);
                  }
                });
              }
              
              parameters = {
                'type': 'object',
                'properties': properties,
                'required': required,
              };
            } else if (params is String) {
              // 尝试解析字符串参数
              try {
                final parsedParams = jsonDecode(params);
                if (parsedParams is Map && parsedParams.containsKey('properties')) {
                  final properties = <String, dynamic>{};
                  final required = <String>[];
                  
                  parsedParams['properties'].forEach((key, value) {
                    properties[key] = {
                      'type': value['type'] ?? 'string',
                      'description': value['description'] ?? '',
                    };
                    
                    if (parsedParams.containsKey('required') && 
                        parsedParams['required'] is List && 
                        (parsedParams['required'] as List).contains(key)) {
                      required.add(key);
                    }
                  });
                  
                  parameters = {
                    'type': 'object',
                    'properties': properties,
                    'required': required,
                  };
                }
              } catch (e) {
                print('解析工具参数时出错: $e');
                // 参数格式不正确，使用空对象
                parameters = {
                  'type': 'object',
                  'properties': {},
                };
              }
            } else {
              // 参数格式不正确，使用空对象
              parameters = {
                'type': 'object',
                'properties': {},
              };
            }
          } else {
            // 没有参数，使用空对象
            parameters = {
              'type': 'object',
              'properties': {},
            };
          }
          
          return {
            'type': 'function',
            'function': {
              'name': tool['name'],
              'description': tool['description'] ?? '无描述',
              'parameters': parameters,
            }
          };
        }).toList();
        
        requestBody['tools'] = tools;
        requestBody['tool_choice'] = 'auto';
      }
      
      print('请求体: ${jsonEncode(requestBody)}');
      
      final response = await http.post(
        Uri.parse(_endpoint),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_apiKey',
        },
        body: jsonEncode(requestBody),
      );
      
      // 解析响应
      print('状态码: ${response.statusCode}');
      print('响应体: ${response.body}');
      
      if (response.statusCode == 200) {
        try {
          // 确保正确处理UTF-8编码
          String responseBody = utf8.decode(response.bodyBytes);
          print('UTF-8解码后的响应体: $responseBody');
          
          // 打印原始字节用于调试
          print('原始响应字节: ${response.bodyBytes}');
          
          // 清理响应体中的空白行和空格
          responseBody = responseBody.replaceAll(RegExp(r'\s*\n\s*'), '').trim();
          if (responseBody.isEmpty) {
            throw Exception('响应体为空');
          }
          
          // 使用正则表达式提取JSON部分
          final RegExp jsonRegex = RegExp(r'(\{.*\})');
          final Match? match = jsonRegex.firstMatch(responseBody);
          
          if (match != null && match.group(1) != null) {
            responseBody = match.group(1)!;
            print('提取的JSON: $responseBody');
          } else {
            // 查找JSON开始的位置（第一个{或[）
            final int jsonStartIndex = responseBody.indexOf(RegExp(r'[\{\[]'));
            if (jsonStartIndex > 0) {
              responseBody = responseBody.substring(jsonStartIndex);
            }
          }
          
          // 移除所有不可见字符
          responseBody = responseBody.replaceAll(RegExp(r'[\x00-\x1F\x7F-\x9F]'), '');
          
          print('清理后的响应体: $responseBody');
          
          // 创建一个完全新的字符串对象
          String jsonStr = '';
          for (int i = 0; i < responseBody.length; i++) {
            jsonStr += responseBody[i];
          }
          
          // 尝试手动解析JSON
          Map<String, dynamic> data = {};
          
          try {
            // 使用自定义的安全解析方法
            data = _safeJsonDecode(jsonStr);
            print('成功解析JSON: ${data.length} 个键');
          } catch (e) {
            print('JSON解析失败，尝试手动提取关键信息: $e');
            
            // 如果所有解析方法都失败，手动提取关键信息
            data = _extractDataManually(jsonStr);
          }
          
          if (data.containsKey('choices') && 
              data['choices'] is List && 
              data['choices'].isNotEmpty && 
              data['choices'][0].containsKey('message')) {
            
            final message = data['choices'][0]['message'];
            
            // 检查是否有工具调用
            if (message.containsKey('tool_calls') && 
                message['tool_calls'] is List && 
                message['tool_calls'].isNotEmpty) {
              
              // 处理工具调用
              final toolCalls = message['tool_calls'] as List;
              final firstToolCall = toolCalls[0];
              
              // 获取工具调用信息
              String toolName = '';
              Map<String, dynamic> toolArguments = {};
              String toolCallId = '';
              
              if (firstToolCall.containsKey('id')) {
                toolCallId = firstToolCall['id'];
              } else {
                toolCallId = 'call_${DateTime.now().millisecondsSinceEpoch}';
              }
              
              if (firstToolCall.containsKey('function')) {
                final function = firstToolCall['function'];
                if (function.containsKey('name')) {
                  toolName = function['name'];
                }
                
                if (function.containsKey('arguments')) {
                  final arguments = function['arguments'];
                  if (arguments is String && arguments.isNotEmpty) {
                    try {
                      toolArguments = jsonDecode(arguments) as Map<String, dynamic>;
                    } catch (e) {
                      print('解析工具参数时出错: $e');
                      toolArguments = {};
                    }
                  } else if (arguments is Map) {
                    toolArguments = Map<String, dynamic>.from(arguments);
                  }
                }
              }
              
              setState(() {
                _isTyping = false;
                _isExecutingTool = true;
                _currentToolCall = {
                  'name': toolName,
                  'arguments': toolArguments,
                  'service': _activeTools.firstWhere(
                    (t) => t['name'] == toolName, 
                    orElse: () => {'service': '未知服务'}
                  )['service'],
                };
                _currentToolCallId = toolCallId;
                
                // 添加工具调用消息
                _messages.add(
                  ChatMessage(
                    text: '正在调用工具: $toolName\n参数: ${jsonEncode(toolArguments)}',
                    isUser: false,
                    isTool: true,
                  ),
                );
              });
              
              // 模拟工具执行
              _executeToolCall(toolName, toolArguments);
              
            } else if (message.containsKey('content') && message['content'] != null) {
              // 普通文本响应
              final String aiResponse = message['content'];
              
              setState(() {
                _isTyping = false;
                _messages.add(
                  ChatMessage(
                    text: aiResponse,
                    isUser: false,
                  ),
                );
              });
            } else {
              throw Exception('API响应格式不符合预期: $data');
            }
          } else {
            throw Exception('API响应格式不符合预期: $data');
          }
        } catch (e) {
          print('解析响应时出错: $e');
          setState(() {
            _isTyping = false;
            _messages.add(
              ChatMessage(
                text: '解析AI响应时出错: $e',
                isUser: false,
                isError: true,
              ),
            );
          });
        }
      } else {
        // 错误处理 - 尝试解析错误信息
        String errorMessage = '请求失败: HTTP ${response.statusCode}';
        
        try {
          final errorData = jsonDecode(response.body);
          if (errorData.containsKey('error') && 
              errorData['error'].containsKey('message')) {
            errorMessage += '\n${errorData['error']['message']}';
            
            // 检查是否有更详细的错误信息
            if (errorData['error'].containsKey('metadata') && 
                errorData['error']['metadata'].containsKey('raw')) {
              final rawError = errorData['error']['metadata']['raw'];
              try {
                final Map<String, dynamic> rawErrorData = jsonDecode(rawError);
                if (rawErrorData.containsKey('error') && 
                    rawErrorData['error'].containsKey('message')) {
                  errorMessage += '\n详细信息: ${rawErrorData['error']['message']}';
                }
              } catch (e) {
                // 如果raw字段不是有效的JSON，直接使用原始字符串
                errorMessage += '\n详细信息: $rawError';
              }
            }
          }
        } catch (e) {
          // 如果无法解析JSON，直接使用响应体
          errorMessage += '\n${response.body}';
        }
        
        setState(() {
          _isTyping = false;
          _messages.add(
            ChatMessage(
              text: errorMessage,
              isUser: false,
              isError: true,
            ),
          );
        });
      }
    } catch (e) {
      print('捕获到异常: $e');
      setState(() {
        _isTyping = false;
        _messages.add(
          ChatMessage(
            text: '发送请求时出错: $e',
            isUser: false,
            isError: true,
          ),
        );
      });
    }
  }
  
  // 执行工具调用
  Future<void> _executeToolCall(String toolName, Map<String, dynamic> arguments) async {
    // 模拟工具执行，延迟1秒
    await Future.delayed(const Duration(seconds: 1));
    
    // 根据工具名称生成模拟响应
    String toolResponse = '';
    
    switch (toolName) {
      case 'add':
        // 尝试从参数中提取数字
        int a = 0;
        int b = 0;
        
        // 检查参数是否为空
        if (arguments.isEmpty) {
          // 尝试从最后一条用户消息中提取数字
          final lastUserMessage = _messages.lastWhere((msg) => msg.isUser, orElse: () => ChatMessage(text: '', isUser: true));
          final numbers = _extractNumbersFromText(lastUserMessage.text);
          
          if (numbers.length >= 2) {
            a = numbers[0];
            b = numbers[1];
          } else if (numbers.length == 1) {
            a = numbers[0];
            b = 0;
          } else {
            // 使用默认值
            a = 5;
            b = 10;
          }
        } else {
          // 从参数中提取
          if (arguments.containsKey('a')) {
            a = int.tryParse(arguments['a'].toString()) ?? 0;
          }
          if (arguments.containsKey('b')) {
            b = int.tryParse(arguments['b'].toString()) ?? 0;
          }
        }
        
        int result = a + b;
        toolResponse = '$a + $b = $result';
        print('执行加法工具: $a + $b = $result');
        break;
      case 'searchRepo':
        toolResponse = '找到以下仓库:\n1. flutter/flutter - Flutter框架\n2. facebook/react - React框架\n3. tensorflow/tensorflow - TensorFlow机器学习库';
        break;
      case 'createIssue':
        toolResponse = 'Issue已创建，编号: #${DateTime.now().millisecondsSinceEpoch % 1000}';
        break;
      case 'sendEmail':
        toolResponse = '邮件已发送至: ${arguments['to']}';
        break;
      case 'readEmails':
        toolResponse = '最新邮件:\n1. [重要] 项目更新通知\n2. 会议邀请: 产品讨论\n3. 您的订单已发货';
        break;
      case 'getWeather':
        toolResponse = '${arguments['city']}天气:\n今天: 晴，温度 18°C-25°C\n明天: 多云，温度 15°C-22°C';
        break;
      default:
        toolResponse = '工具执行完成';
    }
    
    // 添加工具响应到消息列表
    setState(() {
      _messages.add(
        ChatMessage(
          text: toolResponse,
          isUser: false,
          isToolResponse: true,
        ),
      );
      _isExecutingTool = false;
    });
    
    // 继续对话，将工具响应发送给AI
    await _continueConversationWithToolResponse(toolName, toolResponse);
    
    // 重置工具调用状态
    setState(() {
      _currentToolCall = null;
      _currentToolCallId = null;
    });
  }
  
  // 从文本中提取数字
  List<int> _extractNumbersFromText(String text) {
    final List<int> numbers = [];
    
    // 使用正则表达式匹配数字
    final regex = RegExp(r'\d+');
    final matches = regex.allMatches(text);
    
    for (final match in matches) {
      final number = int.tryParse(match.group(0) ?? '');
      if (number != null) {
        numbers.add(number);
      }
    }
    
    return numbers;
  }

  // 将工具响应发送给AI继续对话
  Future<void> _continueConversationWithToolResponse(String toolName, String toolResponse) async {
    setState(() {
      _isTyping = true;
    });
    
    try {
      // 准备消息历史，包括工具响应
      final List<Map<String, dynamic>> messageHistory = [];
      
      // 第一步：收集所有普通消息
      for (var msg in _messages) {
        if (msg.isUser) {
          // 用户消息
          messageHistory.add({
            'role': 'user',
            'content': msg.text,
          });
        } else if (!msg.isUser && !msg.isError && !msg.isTool && !msg.isToolResponse) {
          // 普通AI消息
          messageHistory.add({
            'role': 'assistant',
            'content': msg.text,
          });
        }
      }
      
      // 第二步：添加最后一条AI消息（包含工具调用）
      if (_currentToolCallId != null) {
        print('添加工具调用消息，ID: $_currentToolCallId, 工具名称: $toolName');
        
        // 构建包含工具调用的消息
        final toolUseMessage = {
          'role': 'assistant',
          'content': '我需要使用工具来回答您的问题',
          'tool_calls': [
            {
              'id': _currentToolCallId,
              'type': 'function',
              'function': {
                'name': toolName,
                'arguments': jsonEncode(_currentToolCall!['arguments'] ?? {})
              }
            }
          ]
        };
        
        messageHistory.add(toolUseMessage);
        print('工具调用消息: $toolUseMessage');
        
        // 第三步：添加工具结果消息
        final toolResultMessage = {
          'role': 'tool',
          'tool_call_id': _currentToolCallId,
          'content': toolResponse
        };
        
        messageHistory.add(toolResultMessage);
        print('工具结果消息: $toolResultMessage');
      }
      
      print('发送到API的消息(带工具响应): $messageHistory');
      
      // 构建API请求体
      final Map<String, dynamic> requestBody = {
        'model': _availableModels.firstWhere((model) => model.name == _selectedModel).id,
        'messages': messageHistory,
      };
      
      // 如果有活跃的工具，添加工具配置
      if (_enableTools && _activeTools.isNotEmpty) {
        // 将工具转换为OpenAI格式的工具定义
        final List<Map<String, dynamic>> tools = _activeTools.map((tool) {
          // 检查参数是否已经是标准格式
          Map<String, dynamic> parameters;
          
          if (tool['parameters'] != null) {
            if (tool['parameters'] is Map && tool['parameters']['type'] == 'object') {
              // 参数已经是标准格式，直接使用
              parameters = Map<String, dynamic>.from(tool['parameters']);
            } else if (tool['parameters'] is Map) {
              // 参数是简单的键值对，需要转换为标准格式
              Map<String, dynamic> properties = {};
              List<String> required = [];
              
              (tool['parameters'] as Map<String, dynamic>).forEach((key, value) {
                // 如果值是字符串，转换为描述
                if (value is String) {
                  properties[key] = {
                    'type': 'string',
                    'description': value
                  };
                  // 默认所有参数都是必需的
                  required.add(key);
                } 
                // 如果值是Map，可能已经有类型定义
                else if (value is Map) {
                  properties[key] = value;
                  // 如果没有明确标记为可选，则视为必需
                  if (value['required'] != false) {
                    required.add(key);
                  }
                }
              });
              
              parameters = {
                'type': 'object',
                'properties': properties,
                'required': required,
              };
            } else {
              // 参数格式不正确，使用空对象
              parameters = {
                'type': 'object',
                'properties': {},
              };
            }
          } else {
            // 没有参数，使用空对象
            parameters = {
              'type': 'object',
              'properties': {},
            };
          }
          
          return {
            'type': 'function',
            'function': {
              'name': tool['name'],
              'description': tool['description'] ?? '无描述',
              'parameters': parameters,
            }
          };
        }).toList();
        
        requestBody['tools'] = tools;
        requestBody['tool_choice'] = 'auto';
      }
      
      final response = await http.post(
        Uri.parse(_endpoint),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_apiKey',
        },
        body: jsonEncode(requestBody),
      );
      
      if (response.statusCode == 200) {
        // 确保正确处理UTF-8编码
        String responseBody = utf8.decode(response.bodyBytes);
        print('UTF-8解码后的响应体: $responseBody');
        
        // 打印原始字节用于调试
        print('原始响应字节: ${response.bodyBytes}');
        
        // 清理响应体中的空白行和空格
        responseBody = responseBody.replaceAll(RegExp(r'\s*\n\s*'), '').trim();
        if (responseBody.isEmpty) {
          throw Exception('响应体为空');
        }
        
        // 使用正则表达式提取JSON部分
        final RegExp jsonRegex = RegExp(r'(\{.*\})');
        final Match? match = jsonRegex.firstMatch(responseBody);
        
        if (match != null && match.group(1) != null) {
          responseBody = match.group(1)!;
          print('提取的JSON: $responseBody');
        } else {
          // 查找JSON开始的位置（第一个{或[）
          final int jsonStartIndex = responseBody.indexOf(RegExp(r'[\{\[]'));
          if (jsonStartIndex > 0) {
            responseBody = responseBody.substring(jsonStartIndex);
          }
        }
        
        // 移除所有不可见字符
        responseBody = responseBody.replaceAll(RegExp(r'[\x00-\x1F\x7F-\x9F]'), '');
        
        print('清理后的响应体: $responseBody');
        
        // 创建一个完全新的字符串对象
        String jsonStr = '';
        for (int i = 0; i < responseBody.length; i++) {
          jsonStr += responseBody[i];
        }
        
        // 尝试手动解析JSON
        Map<String, dynamic> data = {};
        
        try {
          // 使用自定义的安全解析方法
          data = _safeJsonDecode(jsonStr);
          print('成功解析JSON: ${data.length} 个键');
        } catch (e) {
          print('JSON解析失败，尝试手动提取关键信息: $e');
          
          // 如果所有解析方法都失败，手动提取关键信息
          data = _extractDataManually(jsonStr);
        }
        
        if (data.containsKey('choices') && 
            data['choices'] is List && 
            data['choices'].isNotEmpty && 
            data['choices'][0].containsKey('message')) {
          
          final message = data['choices'][0]['message'];
          
          // 检查是否有工具调用
          if (message.containsKey('tool_calls') && 
              message['tool_calls'] is List && 
              message['tool_calls'].isNotEmpty) {
            
            // 处理工具调用
            final toolCalls = message['tool_calls'] as List;
            final firstToolCall = toolCalls[0];
            
            // 获取工具调用信息
            final toolName = firstToolCall['function']['name'];
            final toolArguments = jsonDecode(firstToolCall['function']['arguments']);
            final toolCallId = firstToolCall['id'];
            
            setState(() {
              _isTyping = false;
              _isExecutingTool = true;
              _currentToolCall = {
                'name': toolName,
                'arguments': toolArguments,
                'service': _activeTools.firstWhere((t) => t['name'] == toolName)['service'],
              };
              _currentToolCallId = toolCallId;
              
              // 添加工具调用消息
              _messages.add(
                ChatMessage(
                  text: '正在调用工具: $toolName\n参数: ${jsonEncode(toolArguments)}',
                  isUser: false,
                  isTool: true,
                ),
              );
            });
            
            // 模拟工具执行
            _executeToolCall(toolName, toolArguments);
            
          } else if (message.containsKey('content') && message['content'] != null) {
            // 普通文本响应
            final String aiResponse = message['content'];
            
            setState(() {
              _isTyping = false;
              _messages.add(
                ChatMessage(
                  text: aiResponse,
                  isUser: false,
                ),
              );
            });
          } else {
            throw Exception('API响应格式不符合预期');
          }
        } else {
          throw Exception('API响应格式不符合预期');
        }
      } else {
        // 错误处理
        setState(() {
          _isTyping = false;
          _messages.add(
            ChatMessage(
              text: '请求失败: HTTP ${response.statusCode}',
              isUser: false,
              isError: true,
            ),
          );
        });
      }
    } catch (e) {
      setState(() {
        _isTyping = false;
        _messages.add(
          ChatMessage(
            text: '处理工具响应时出错: $e',
            isUser: false,
            isError: true,
          ),
        );
      });
    }
  }

  // 自定义的安全JSON解析方法
  Map<String, dynamic> _safeJsonDecode(String jsonStr) {
    try {
      // 先尝试直接解析
      return jsonDecode(jsonStr) as Map<String, dynamic>;
    } catch (e) {
      print('直接解析失败: $e');
      
      try {
        // 尝试使用JsonDecoder
        final decoder = JsonDecoder();
        return decoder.convert(jsonStr) as Map<String, dynamic>;
      } catch (e2) {
        print('JsonDecoder解析失败: $e2');
        
        // 如果还是失败，尝试手动修复JSON
        if (jsonStr.startsWith('{') && !jsonStr.endsWith('}')) {
          jsonStr = '$jsonStr}';
          try {
            return jsonDecode(jsonStr) as Map<String, dynamic>;
          } catch (e3) {
            print('修复后解析失败: $e3');
          }
        }
        
        throw Exception('JSON解析失败: $e2');
      }
    }
  }

  // 手动提取关键信息
  Map<String, dynamic> _extractDataManually(String jsonStr) {
    Map<String, dynamic> result = {
      'choices': [
        {
          'message': {
            'content': '',
            'tool_calls': []
          }
        }
      ]
    };
    
    try {
      // 提取content内容
      final RegExp contentRegex = RegExp(r'"content":"([^"]*)"');
      final Match? contentMatch = contentRegex.firstMatch(jsonStr);
      if (contentMatch != null && contentMatch.group(1) != null) {
        result['choices'][0]['message']['content'] = contentMatch.group(1)!;
      }
      
      // 提取工具名称
      final RegExp toolNameRegex = RegExp(r'"name":"([^"]*)"');
      final Match? toolNameMatch = toolNameRegex.firstMatch(jsonStr);
      if (toolNameMatch != null && toolNameMatch.group(1) != null) {
        final toolName = toolNameMatch.group(1)!;
        result['choices'][0]['message']['tool_calls'] = [
          {
            'function': {
              'name': toolName,
              'arguments': '{}'
            }
          }
        ];
      }
      
      // 提取arguments
      final RegExp argumentsRegex = RegExp(r'"arguments":"([^"]*)"');
      final Match? argumentsMatch = argumentsRegex.firstMatch(jsonStr);
      if (argumentsMatch != null && argumentsMatch.group(1) != null) {
        result['choices'][0]['message']['tool_calls'][0]['function']['arguments'] = 
            argumentsMatch.group(1)!;
      }
      
      print('手动提取的数据: $result');
    } catch (e) {
      print('手动提取数据时出错: $e');
    }
    
    return result;
  }

  void _showModelSelector() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(16),
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.7,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                '选择AI模型',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  itemCount: _availableModels.length,
                  itemBuilder: (context, index) {
                    final model = _availableModels[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(
                          color: _selectedModel == model.name
                              ? Colors.indigo
                              : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: _selectedModel == model.name
                                      ? Colors.indigo
                                      : Colors.grey[300],
                                  child: Icon(
                                    Icons.smart_toy,
                                    color: Colors.white,
                                    size: 16,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    model.name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                if (_selectedModel == model.name)
                                  const Icon(Icons.check_circle, color: Colors.indigo),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              model.description,
                              style: TextStyle(
                                color: Colors.grey[700],
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                _buildPriceTag('输入', '\$${model.inputPrice}/1M tokens'),
                                const SizedBox(width: 8),
                                _buildPriceTag('输出', '\$${model.outputPrice}/1M tokens'),
                                if (double.parse(model.imagePrice) > 0)
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8),
                                    child: _buildPriceTag('图像', '\$${model.imagePrice}/1K'),
                                  ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    _selectedModel = model.name;
                                  });
                                  Navigator.pop(context);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _selectedModel == model.name
                                      ? Colors.indigo
                                      : Colors.grey[200],
                                  foregroundColor: _selectedModel == model.name
                                      ? Colors.white
                                      : Colors.indigo,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(_selectedModel == model.name ? '已选择' : '选择'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPriceTag(String label, String price) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.indigo.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.indigo[700],
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 4),
          Text(
            price,
            style: TextStyle(
              color: Colors.indigo[700],
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  void _showToolsManager() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Container(
              padding: const EdgeInsets.all(16),
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.7,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'MCP工具管理',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Row(
                        children: [
                          const Text('启用工具'),
                          Switch(
                            value: _enableTools,
                            activeColor: Colors.indigo,
                            onChanged: (value) {
                              setState(() {
                                _enableTools = value;
                              });
                              this.setState(() {});
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: _availableMcpServices.isEmpty
                        ? const Center(
                            child: Text('没有可用的MCP服务'),
                          )
                        : ListView.builder(
                            itemCount: _availableMcpServices.length,
                            itemBuilder: (context, index) {
                              final service = _availableMcpServices[index];
                              return Card(
                                margin: const EdgeInsets.only(bottom: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: ExpansionTile(
                                  leading: CircleAvatar(
                                    backgroundColor: service.isActive
                                        ? Colors.indigo
                                        : Colors.grey[300],
                                    child: FaIcon(
                                      service.icon,
                                      color: Colors.white,
                                      size: 16,
                                    ),
                                  ),
                                  title: Text(
                                    service.name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  subtitle: Text(service.description),
                                  trailing: Switch(
                                    value: service.isActive,
                                    activeColor: Colors.indigo,
                                    onChanged: (value) {
                                      setState(() {
                                        service.isActive = value;
                                      });
                                      
                                      // 保存更改
                                      McpStorageService.saveMcpService(service);
                                      
                                      // 更新活跃工具列表
                                      this.setState(() {
                                        _updateActiveTools();
                                      });
                                    },
                                  ),
                                  children: [
                                    if (service.tools.isEmpty)
                                      const Padding(
                                        padding: EdgeInsets.all(16),
                                        child: Text('该服务没有提供任何工具'),
                                      )
                                    else
                                      ListView.builder(
                                        shrinkWrap: true,
                                        physics: const NeverScrollableScrollPhysics(),
                                        itemCount: service.tools.length,
                                        itemBuilder: (context, toolIndex) {
                                          final tool = service.tools[toolIndex];
                                          final bool isToolEnabled = tool['enabled'] ?? true;
                                          
                                          return ListTile(
                                            leading: const Icon(Icons.build),
                                            title: Text(tool['name']),
                                            subtitle: Text(tool['description'] ?? '无描述'),
                                            trailing: Switch(
                                              value: isToolEnabled,
                                              activeColor: Colors.indigo,
                                              onChanged: (value) {
                                                setState(() {
                                                  tool['enabled'] = value;
                                                });
                                                
                                                // 保存更改
                                                McpStorageService.saveMcpService(service);
                                                
                                                // 更新活跃工具列表
                                                this.setState(() {
                                                  _updateActiveTools();
                                                });
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.indigo,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('完成'),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI对话'),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.smart_toy),
            tooltip: '选择AI模型',
            onPressed: () {
              _showModelSelector();
            },
          ),
          IconButton(
            icon: const Icon(Icons.build),
            tooltip: '管理MCP工具',
            onPressed: () {
              _showToolsManager();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 1,
                  blurRadius: 3,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: _showModelSelector,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.indigo.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.indigo.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.smart_toy,
                              color: Colors.indigo,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _selectedModel,
                              style: const TextStyle(
                                color: Colors.indigo,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Icon(
                              Icons.arrow_drop_down,
                              color: Colors.indigo,
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_enableTools) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.amber.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.amber.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.build,
                              color: Colors.amber,
                              size: 14,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '工具已启用 (${_activeTools.length})',
                              style: const TextStyle(
                                color: Colors.amber,
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 12),
                // 添加一个混合推理模式的开关
                if (_selectedModel == 'Claude 3.7 Sonnet')
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        '扩展推理模式',
                        style: TextStyle(
                          color: Colors.indigo,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Switch(
                        value: _extendedReasoning,
                        activeColor: Colors.indigo,
                        onChanged: (value) {
                          setState(() {
                            _extendedReasoning = value;
                          });
                        },
                      ),
                      const SizedBox(width: 4),
                      Tooltip(
                        message: '启用扩展推理模式可以提高数学、编码和复杂问题的准确性，但会增加响应时间',
                        child: const Icon(
                          Icons.info_outline,
                          color: Colors.indigo,
                          size: 16,
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.chat_bubble_outline,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          '开始与 $_selectedModel 对话',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _selectedModel == 'Claude 3.7 Sonnet' && _extendedReasoning
                              ? '已启用扩展推理模式，适合复杂问题'
                              : '普通对话模式',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[500],
                          ),
                        ),
                        if (_enableTools) ...[
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              children: [
                                const Text(
                                  '已启用MCP工具',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.amber,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  '可用工具: ${_activeTools.map((t) => t['name']).join(', ')}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey[700],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _messages.length,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    reverse: false,
                    itemBuilder: (context, index) {
                      return _messages[index];
                    },
                  ),
          ),
          if (_isTyping || _isExecutingTool)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              alignment: Alignment.centerLeft,
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _isExecutingTool 
                          ? Colors.amber.withOpacity(0.1) 
                          : Colors.grey[200],
                      borderRadius: BorderRadius.circular(20),
                      border: _isExecutingTool 
                          ? Border.all(color: Colors.amber.withOpacity(0.3))
                          : null,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              _isExecutingTool 
                                  ? Colors.amber
                                  : (_extendedReasoning ? Colors.orange : Colors.indigo)
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _isExecutingTool 
                              ? '正在执行工具: ${_currentToolCall!['name']}'
                              : (_extendedReasoning ? 'AI正在深度思考...' : 'AI正在思考...'),
                          style: TextStyle(
                            color: _isExecutingTool 
                                ? Colors.amber
                                : (_extendedReasoning ? Colors.orange : Colors.indigo)
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 1,
                  blurRadius: 3,
                  offset: const Offset(0, -1),
                ),
              ],
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.attach_file),
                  color: Colors.grey[600],
                  onPressed: () {
                    // 实现文件/图像上传功能
                  },
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    maxLines: null,
                    decoration: InputDecoration(
                      hintText: '输入消息...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.grey[100],
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 10,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  color: Colors.indigo,
                  onPressed: _isTyping || _isExecutingTool ? null : _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ChatMessage extends StatelessWidget {
  final String text;
  final bool isUser;
  final bool isError;
  final bool isTool;
  final bool isToolResponse;

  const ChatMessage({
    super.key,
    required this.text,
    required this.isUser,
    this.isError = false,
    this.isTool = false,
    this.isToolResponse = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser)
            CircleAvatar(
              backgroundColor: isError 
                  ? Colors.red 
                  : (isTool 
                      ? Colors.amber
                      : (isToolResponse ? Colors.green : Colors.indigo)),
              child: Icon(
                isError 
                    ? Icons.error 
                    : (isTool 
                        ? Icons.build
                        : (isToolResponse ? Icons.check : Icons.smart_toy)),
                color: Colors.white,
                size: 18,
              ),
            ),
          const SizedBox(width: 8),
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: isUser 
                    ? Colors.indigo 
                    : (isError 
                        ? Colors.red.withOpacity(0.1) 
                        : (isTool 
                            ? Colors.amber.withOpacity(0.1)
                            : (isToolResponse 
                                ? Colors.green.withOpacity(0.1)
                                : Colors.grey[200]))),
                borderRadius: BorderRadius.circular(20),
                border: !isUser && (isTool || isToolResponse)
                    ? Border.all(
                        color: isTool ? Colors.amber : Colors.green,
                        width: 1,
                      )
                    : null,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isUser && (isTool || isToolResponse))
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        isTool ? '工具调用' : '工具响应',
                        style: TextStyle(
                          color: isTool ? Colors.amber[800] : Colors.green[800],
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  Text(
                    text,
                    style: TextStyle(
                      color: isUser 
                          ? Colors.white 
                          : (isError 
                              ? Colors.red 
                              : (isTool 
                                  ? Colors.amber[800]
                                  : (isToolResponse 
                                      ? Colors.green[800]
                                      : Colors.black87))),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          if (isUser)
            const CircleAvatar(
              backgroundColor: Colors.blue,
              child: Icon(
                Icons.person,
                color: Colors.white,
                size: 18,
              ),
            ),
        ],
      ),
    );
  }
}

// 模型选项类
class ModelOption {
  final String name;
  final String id;
  final String description;
  final String inputPrice;
  final String outputPrice;
  final String imagePrice;

  ModelOption({
    required this.name,
    required this.id,
    required this.description,
    required this.inputPrice,
    required this.outputPrice,
    required this.imagePrice,
  });
}