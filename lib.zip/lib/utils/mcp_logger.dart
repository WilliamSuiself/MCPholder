class MCPLogger {
  static void log(String message) {
    print("[MCP] $message");
  }
  
  static void error(String message, [Exception? e]) {
    print("[MCP ERROR] $message");
    if (e != null) {
      print(e.toString());
    }
  }
} 