# MCP客户端应用 - 项目结构图

## 项目概述
MCP客户端应用是一个基于Flutter的移动应用，用于演示AI模型如何通过Model Context Protocol (MCP)与外部工具和API交互。应用提供了AI对话界面，以及MCP服务的管理和测试功能。该应用已集成了OpenRouter API，可实际连接Claude 3.7 Sonnet等多种AI模型。

## 文件结构

### 主入口
- **lib/main.dart**：应用的入口文件
  - `MyApp` 类：应用的根组件，设置主题和路由
  - `MainScreen` 类：主屏幕，包含底部导航栏和三个主要页面的切换功能
  
### 页面组件
- **lib/screens/chat_screen.dart**：AI对话页面
  - `ChatScreen` 类：AI对话的主界面
  - `_ChatScreenState` 类：管理对话状态、模型选择和消息发送
  - `ChatMessage` 类：聊天消息展示组件
  - `ModelOption` 类：定义AI模型的配置信息（名称、ID、描述、价格等）
  
- **lib/screens/services_screen.dart**：MCP服务页面
  - `ServicesScreen` 类：MCP服务列表页面
  - `_ServicesScreenState` 类：管理MCP服务列表和状态
  - `McpService` 类：MCP服务的数据模型
  
- **lib/screens/test_service_screen.dart**：MCP服务测试页面
  - `TestServiceScreen` 类：测试MCP服务连接的页面
  - `_TestServiceScreenState` 类：管理服务测试表单和连接测试流程

### 功能和交互点

#### AI对话页面 (chat_screen.dart)
- **功能**：
  - 模型选择：支持多种AI模型，包括Claude 3.7 Sonnet、Claude 3 Opus、GPT-4o和Gemini 1.5 Pro
  - 扩展推理模式：特别为Claude 3.7 Sonnet提供的高级思考模式
  - 消息收发：支持向AI发送消息并展示回复
  - API集成：通过OpenRouter API连接到不同的AI模型服务

- **主要方法**：
  - `_sendMessage()`：发送消息到OpenRouter API并获取AI回复
    - 准备消息历史并构建API请求
    - 处理API响应和错误情况
    - 使用UTF-8解码确保中文正确显示
  - `_showModelSelector()`：展示模型选择界面
  - `_buildPriceTag()`：构建价格标签UI组件
  - `build()`：构建对话界面UI

#### MCP服务页面 (services_screen.dart)
- **功能**：
  - 服务列表：显示可用的MCP服务及其状态
  - 服务状态管理：启用/禁用服务
  - 服务详情：查看服务的详细信息

- **主要方法**：
  - `_buildStatusCard()`：构建状态卡片UI
  - `_showServiceDetails()`：显示服务详情对话框
  - `_buildFeatureItem()`：构建服务功能项目UI
  - `build()`：构建服务管理界面UI

#### MCP服务测试页面 (test_service_screen.dart)
- **功能**：
  - 服务配置：输入MCP服务的名称、URL、端口和API密钥
  - 连接测试：测试服务连接是否成功
  - 服务保存：保存测试成功的服务

- **主要方法**：
  - `_testConnection()`：测试服务连接
  - `_resetForm()`：重置表单
  - `_saveService()`：保存服务配置
  - `_buildTextField()`：构建表单输入字段
  - `build()`：构建服务测试界面UI

## 类与组件

### ChatMessage 类
- **功能**：显示聊天消息气泡
- **属性**：
  - `text`：消息文本内容
  - `isUser`：是否为用户消息
  - `isError`：是否为错误消息
- **视觉特性**：
  - 用户消息：蓝色背景、右侧显示
  - AI消息：灰色背景、左侧显示
  - 错误消息：红色边框和文字

### ModelOption 类
- **功能**：存储AI模型信息
- **属性**：
  - `name`：模型名称（如"Claude 3.7 Sonnet"）
  - `id`：模型ID（如"anthropic/claude-3.7-sonnet"）
  - `description`：模型描述
  - `inputPrice`：输入价格（每百万token）
  - `outputPrice`：输出价格（每百万token）
  - `imagePrice`：图像处理价格（每千图像）

### McpService 类
- **功能**：存储MCP服务信息
- **属性**：
  - `name`：服务名称
  - `description`：服务描述
  - `icon`：服务图标
  - `isActive`：服务是否激活

## 交互流程

1. **AI对话流程**：
   - 用户在输入框输入消息
   - 点击发送按钮调用`_sendMessage()`方法
   - 消息被添加到聊天记录中，并发送到OpenRouter API
   - 接收AI回复并显示在聊天界面

2. **模型选择流程**：
   - 用户点击模型选择器调用`_showModelSelector()`方法
   - 显示模型选择底部弹窗
   - 用户选择模型后更新`_selectedModel`变量

3. **MCP服务管理流程**：
   - 服务列表显示在ServicesScreen中
   - 用户可以启用/禁用服务
   - 点击服务项目可查看服务详情

4. **MCP服务测试流程**：
   - 用户填写服务配置表单
   - 点击"测试连接"按钮调用`_testConnection()`方法
   - 显示测试结果
   - 测试成功可保存服务配置

## 依赖项
- **flutter**：Flutter框架
- **cupertino_icons**：iOS风格图标
- **font_awesome_flutter**：Font Awesome图标集
- **google_fonts**：Google字体
- **http**：HTTP客户端，用于API请求

## API集成
- **OpenRouter API**：
  - 端点：https://openrouter.ai/api/v1/chat/completions
  - 支持多种AI模型调用
  - API密钥已配置（仅用于测试）
  - 请求格式：JSON，包含模型ID和消息历史
  - 响应处理：使用UTF-8解码确保中文正确显示

## 功能重复分析

在当前项目中未发现明显的功能重复。各个组件和页面有明确的职责分工：

1. **chat_screen.dart** 专注于AI对话功能和模型选择
2. **services_screen.dart** 负责MCP服务的管理和展示
3. **test_service_screen.dart** 提供MCP服务的测试和添加功能

这种分离设计符合单一职责原则，有利于代码的维护和扩展。

## 潜在优化点

1. **状态管理**：目前使用的是StatefulWidget的setState管理状态，未来可考虑使用Provider或Riverpod等状态管理方案
2. **API密钥安全**：目前API密钥是硬编码的，应考虑使用flutter_secure_storage等安全存储方案
3. **消息持久化**：添加本地数据库存储聊天历史记录
4. **错误处理**：可以进一步完善网络异常情况的重试机制
5. **主题支持**：实现深色模式和自定义主题
6. **图片上传**：完善附件功能，支持向AI发送图片
7. **本地化**：添加多语言支持
8. **流式响应**：实现流式API响应，实时显示AI回复 