import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class McpService {
  final String name;
  final String description;
  final IconData icon;
  bool isActive;
  final List<Map<String, dynamic>> tools;
  final bool isRemote;
  final String? authUrl;
  final String? accessToken;
  final String? refreshToken;
  final String? apiKey;
  final String? clientId;

  McpService({
    required this.name,
    required this.description,
    required this.icon,
    required this.isActive,
    this.tools = const [],
    this.isRemote = false,
    this.authUrl,
    this.accessToken,
    this.refreshToken,
    this.apiKey,
    this.clientId,
  });
  
  /// 将IconData转换为字符串，用于JSON序列化
  static String _iconDataToString(IconData icon) {
    // 对于FontAwesomeIcons，我们保存其名称
    if (icon.fontFamily == 'FontAwesome') {
      // 尝试查找FontAwesomeIcons中的图标
      for (final entry in _iconMapping.entries) {
        if (entry.value.codePoint == icon.codePoint) {
          return 'fa:${entry.key}';
        }
      }
    }
    
    // 对于其他图标，保存codePoint和fontFamily
    return 'icon:${icon.codePoint}:${icon.fontFamily}';
  }
  
  /// 从字符串转换为IconData，用于JSON反序列化
  static IconData _stringToIconData(String iconStr) {
    if (iconStr.startsWith('fa:')) {
      final iconName = iconStr.substring(3);
      return _iconMapping[iconName] ?? FontAwesomeIcons.question;
    } else if (iconStr.startsWith('icon:')) {
      final parts = iconStr.substring(5).split(':');
      if (parts.length == 2) {
        return IconData(
          int.parse(parts[0]),
          fontFamily: parts[1],
        );
      }
    }
    
    // 默认返回问号图标
    return FontAwesomeIcons.question;
  }
  
  /// 将McpService转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'icon': _iconDataToString(icon),
      'isActive': isActive,
      'tools': tools,
      'isRemote': isRemote,
      'authUrl': authUrl,
      'accessToken': accessToken,
      'refreshToken': refreshToken,
      'apiKey': apiKey,
      'clientId': clientId,
    };
  }
  
  /// 从JSON创建McpService
  factory McpService.fromJson(Map<String, dynamic> json) {
    // 处理tools字段，确保它是List<Map<String, dynamic>>类型
    final List<dynamic> toolsJson = json['tools'] ?? [];
    final List<Map<String, dynamic>> tools = toolsJson
        .map((tool) => tool is Map<String, dynamic> 
            ? tool 
            : Map<String, dynamic>.from(tool))
        .toList();
    
    return McpService(
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      icon: _stringToIconData(json['icon'] ?? ''),
      isActive: json['isActive'] ?? false,
      tools: tools,
      isRemote: json['isRemote'] ?? false,
      authUrl: json['authUrl'],
      accessToken: json['accessToken'],
      refreshToken: json['refreshToken'],
      apiKey: json['apiKey'],
      clientId: json['clientId'],
    );
  }
  
  /// 图标名称到FontAwesomeIcons的映射
  static final Map<String, IconData> _iconMapping = {
    'github': FontAwesomeIcons.github,
    'envelope': FontAwesomeIcons.envelope,
    'calendar': FontAwesomeIcons.calendar,
    'cloud': FontAwesomeIcons.cloud,
    'database': FontAwesomeIcons.database,
    'search': FontAwesomeIcons.search,
    'file': FontAwesomeIcons.file,
    'image': FontAwesomeIcons.image,
    'video': FontAwesomeIcons.video,
    'music': FontAwesomeIcons.music,
    'map': FontAwesomeIcons.map,
    'code': FontAwesomeIcons.code,
    'robot': FontAwesomeIcons.robot,
    'brain': FontAwesomeIcons.brain,
    'question': FontAwesomeIcons.question,
  };
}